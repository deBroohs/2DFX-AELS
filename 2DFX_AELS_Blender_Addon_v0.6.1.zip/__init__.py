import configparser
import io
import json
import math
import re
import struct
import time
from pathlib import Path

import bpy
try:
    import gpu
    from gpu_extras.batch import batch_for_shader
except Exception:
    gpu = None
    batch_for_shader = None
from mathutils import Vector
from bpy.props import BoolProperty
from bpy.props import BoolVectorProperty
from bpy.props import EnumProperty
from bpy.props import FloatProperty
from bpy.props import FloatVectorProperty
from bpy.props import IntProperty
from bpy.props import CollectionProperty
from bpy.props import PointerProperty
from bpy.props import StringProperty
from bpy.types import Operator
from bpy.types import Panel
from bpy.types import PropertyGroup
from bpy_extras.io_utils import ExportHelper
from bpy_extras.io_utils import ImportHelper


EFFECT_NONE = "NONE"
EFFECT_LIGHT = "LIGHT"
CORONA_NONE = "__NONE__"
SHADOW_NONE = "__NONE__"
LIGHT_FACE_FRONT = "FRONT"
LIGHT_FACE_BACK = "BACK"
LIGHT_FACE_LEFT = "LEFT"
LIGHT_FACE_RIGHT = "RIGHT"
LIGHT_FACE_UP = "UP"
LIGHT_FACE_DOWN = "DOWN"

EFFECT_KIND_ITEMS = (
    (EFFECT_NONE, "None", "No AELS light data"),
    (EFFECT_LIGHT, "Light", "GTA emergency-light data"),
)

LIGHT_FACE_ITEMS = (
    (LIGHT_FACE_FRONT, "Front (+Y)", "Visible from the object's local front side", 0),
    (LIGHT_FACE_BACK, "Back (-Y)", "Visible from the object's local back side", 1),
    (LIGHT_FACE_LEFT, "Left (-X)", "Visible from the object's local left side", 2),
    (LIGHT_FACE_RIGHT, "Right (+X)", "Visible from the object's local right side", 3),
    (LIGHT_FACE_UP, "Up (+Z)", "Visible from the object's local top side", 4),
    (LIGHT_FACE_DOWN, "Down (-Z)", "Visible from the object's local bottom side", 5),
)

LIGHT_TYPE_CUSTOM_BLINK = "CUSTOM_BLINK"

LIGHT_TYPE_DEFINITIONS = (
    (0, "DEFAULT", "DEFAULT", "Default SA corona behavior"),
    (1, "RANDOM_FLASHING", "RANDOM_FLASHING", "Random flashing"),
    (2, "RANDOM_FLASHIN_ALWAYS_AT_WET_WEATHER", "RANDOM_FLASHIN_ALWAYS_AT_WET_WEATHER", "Random flashing; always enabled on wet weather"),
    (3, "LIGHTS_ANIM_SPEED_4X", "LIGHTS_ANIM_SPEED_4X", "Animation speed x4"),
    (4, "LIGHTS_ANIM_SPEED_2X", "LIGHTS_ANIM_SPEED_2X", "Animation speed x2"),
    (5, "LIGHTS_ANIM_SPEED_1X", "LIGHTS_ANIM_SPEED_1X", "Animation speed x1"),
    (6, "WARNLIGHT", "WARNLIGHT", "Warning light behavior"),
    (7, "TRAFFICLIGHT", "TRAFFICLIGHT", "Traffic light behavior"),
    (8, "TRAINCROSSLIGHT", "TRAINCROSSLIGHT", "Train crossing light behavior"),
    (9, "DISABLED", "DISABLED", "Disabled light mode"),
    (10, "AT_RAIN_ONLY", "AT_RAIN_ONLY", "Enabled only in rainy weather"),
    (11, "MODE_5S_ON_5S_OFF", "5S_ON_5S_OFF", "5 seconds on, 5 seconds off"),
    (12, "MODE_6S_ON_4S_OFF", "6S_ON_4S_OFF", "6 seconds on, 4 seconds off"),
    (13, "MODE_6S_ON_4S_OFF_2", "6S_ON_4S_OFF_2", "6 seconds on, 4 seconds off, alternate variant"),
)

LIGHT_TYPE_ITEMS = tuple(
    (identifier, label, description, mode)
    for mode, identifier, label, description in LIGHT_TYPE_DEFINITIONS
)

SAPARTICLE_LIGHT_TYPE_PREFIX = "SAPARTICLE_TYPE_"

LIGHT_TYPE_BY_IDENTIFIER = {
    identifier: {
        "identifier": identifier,
        "index": mode,
        "name": label,
        "description": description,
    }
    for mode, identifier, label, description in LIGHT_TYPE_DEFINITIONS
}

FIXED_CORONA_TEXTURES = ("coronastar",)
FIXED_SHADOW_TEXTURES = ("shad_exp",)

DEFAULT_LIGHT_LAYOUT = {
    "corona_enable_reflection": 0,
    "corona_flare_type": 0,
    "shadow_color_multiplier": 40,
    "flags1": 96,
    "shadow_z_distance": 0,
    "flags2": 0x04,
    "look_direction_x": 0,
    "look_direction_y": 0,
    "look_direction_z": 100,
}

CUSTOM_BLINK_CORONA_SHOW_MODE = 9
RUNTIME_DB_MAGIC = b"AEL2"
RUNTIME_DB_VERSION = 1
RUNTIME_LIGHT_RECORD_SIZE = 28

PRESET_CACHE = {
    "textures": [],
    "light_types": [],
    "defaults": {
        "light": {
            "corona_index": 1,
            "shadow_index": 1,
            "distance": 200.0,
            "outerrange": 6.0,
            "size": 5.0,
            "innerrange": 1.0,
            "type_index": 0,
        },
    },
    "ini_path": "",
}

MODEL_ID_CACHE = {}

RW_ID_STRUCT = 0x00000001
RW_ID_STRING = 0x00000002
RW_ID_EXTENSION = 0x00000003
RW_ID_TEXTURE = 0x00000006
RW_ID_MATERIAL = 0x00000007
RW_ID_MATERIAL_LIST = 0x00000008
RW_ID_FRAME_LIST = 0x0000000E
RW_ID_GEOMETRY = 0x0000000F
RW_ID_CLUMP = 0x00000010
RW_ID_ATOMIC = 0x00000014
RW_ID_GEOMETRY_LIST = 0x0000001A
RW_ID_PIPELINE_SET = 0x0253F2F3
RW_ID_2DFX = 0x0253F2F8
RW_ID_EXTRA_VERT_COLOUR = 0x0253F2F9
RW_ID_AELS = 0x41454C53

AELS_METADATA_MAGIC = b"AELS"
AELS_METADATA_VERSION = 10
AELS_BINARY_LIGHT_FLAG_ENABLED = 0x01
AELS_BINARY_LIGHT_FLAG_REQUIRES_SIREN = 0x02
AELS_BINARY_LIGHT_FLAG_DIRECTIONAL = 0x04
AELS_BINARY_LIGHT_FLAG_EXPORT_LEGACY = 0x08
DEFAULT_CORONA_SHOW_MODE = 0

AELS_VEHICLE_CLASS_ITEMS = (
    ("ANY_EMERGENCY", "Any Emergency", "Light can be used by any emergency vehicle class"),
    ("POLICE", "Police", "Police vehicle light"),
    ("AMBULANCE", "Ambulance", "Ambulance vehicle light"),
    ("FIRE", "Fire", "Fire truck vehicle light"),
    ("UTILITY", "Utility", "Utility or service vehicle light"),
)

AELS_BLINK_MODE_SIMPLE = "SIMPLE"
AELS_BLINK_MODE_PATTERN = "PATTERN"

AELS_BLINK_MODE_ITEMS = (
    (AELS_BLINK_MODE_SIMPLE, "Simple", "Use a basic on/off cycle"),
    (AELS_BLINK_MODE_PATTERN, "Manual Pattern", "Manually define each blink step in the cycle"),
)

AELS_PATTERN_TOKEN_RE = re.compile(r"^\s*(-?\d+)\s*$")
DEFAULT_AELS_PATTERN = "160, 160"
VARIANT_LEVEL_NONE = 0
MAX_VARIANT_LEVELS = 6
AELS_PREVIEW_MAX_LIGHTS_DEFAULT = 160
AELS_PREVIEW_DRAW_FPS = 30.0
AELS_PREVIEW_CACHE_SECONDS = 0.25
AELS_LIGHT_MATERIAL_NAME = "aels128"
AELS_LIGHT_TEXTURE_NAME = "aels128"
AELS_LIGHT_ON_TEXTURE_NAME = "aels128on"
AELS_LIGHT_MATERIAL_COLOR = (1.0, 1.0, 1.0, 1.0)
AELS_LIGHT_MATERIAL_DFF_ALPHA = 254

_AELS_PREVIEW_DRAW_HANDLE = None
_AELS_PREVIEW_TIMER_ACTIVE = False
_AELS_PREVIEW_SHADER = None
_AELS_PREVIEW_CACHE = {
    "scene": None,
    "object_count": -1,
    "rebuilt_at": 0.0,
    "objects": [],
}

RW_PIPELINE_NIGHT_VERTEX_COLOURS = 0x53F2009C

RP_GEOMETRY_TEXTURED = 0x00000004
RP_GEOMETRY_PRELIT = 0x00000008
RP_GEOMETRY_NORMALS = 0x00000010
RP_GEOMETRY_LIGHT = 0x00000020
RP_GEOMETRY_TEXTURED2 = 0x00000080
RP_GEOMETRY_NATIVE = 0x01000000


def _addon_dir():
    return Path(__file__).resolve().parent


def _candidate_ini_paths():
    addon_ini = _addon_dir() / "saparticle.ini"
    parent_ini = _addon_dir().parent / "saparticle.ini"
    grandparent_ini = _addon_dir().parent.parent / "saparticle.ini"
    return (addon_ini, parent_ini, grandparent_ini)


def _parse_int(value, fallback):
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


def _parse_float(value, fallback):
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _read_ini_without_slash_comments(path):
    lines = []
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if line.lstrip().startswith("//"):
                continue
            lines.append(line)
    return "".join(lines)


def _u32_to_le_bytes(value):
    value = int(value) & 0xFFFFFFFF
    return tuple((value >> shift) & 0xFF for shift in (0, 8, 16, 24))


def _layout_from_saparticle_light_type(param1, param2, param3):
    param1_bytes = _u32_to_le_bytes(param1)
    param3_bytes = _u32_to_le_bytes(param3)
    layout = dict(DEFAULT_LIGHT_LAYOUT)
    layout["corona_show_mode"] = param1_bytes[0]
    layout["corona_enable_reflection"] = param1_bytes[1]
    layout["corona_flare_type"] = param1_bytes[2]
    layout["shadow_color_multiplier"] = param1_bytes[3]
    layout["flags1"] = int(param2) & 0xFF
    layout["shadow_z_distance"] = param3_bytes[0]
    layout["flags2"] = param3_bytes[1]
    layout["look_direction_x"] = param3_bytes[2]
    layout["look_direction_y"] = param3_bytes[3]
    layout["look_direction_z"] = 0
    return layout


def _light_type_items(_self=None, _context=None):
    return LIGHT_TYPE_ITEMS


def load_presets():
    global PRESET_CACHE

    default_cache = {
        "textures": ["shad_exp", "coronastar"],
        "light_types": [],
        "defaults": {
            "light": {
                "corona_index": 2,
                "shadow_index": 1,
                "distance": 200.0,
                "outerrange": 6.0,
                "size": 5.0,
                "innerrange": 1.0,
                "type_index": 0,
            },
        },
        "ini_path": "",
    }

    ini_path = None
    for candidate in _candidate_ini_paths():
        if candidate.exists():
            ini_path = candidate
            break

    if ini_path is None:
        PRESET_CACHE = default_cache
        return None

    parser = configparser.ConfigParser()
    parser.optionxform = str
    parser.read_string(_read_ini_without_slash_comments(ini_path))

    setup = parser["particlesetup"] if parser.has_section("particlesetup") else {}
    last_light = parser["lastlight"] if parser.has_section("lastlight") else {}
    light_type_section = parser["lighttypes"] if parser.has_section("lighttypes") else {}
    texture_section = parser["texturenames"] if parser.has_section("texturenames") else {}

    texture_count = _parse_int(getattr(setup, "get", lambda *_: None)("numtextures"), 0)
    light_type_count = _parse_int(getattr(setup, "get", lambda *_: None)("numlighttypes"), 0)

    textures = []
    for index in range(1, texture_count + 1):
        name = getattr(texture_section, "get", lambda *_: None)(f"texture{index}")
        if name:
            textures.append(name)

    light_types = []
    for index in range(1, light_type_count + 1):
        get_value = getattr(light_type_section, "get", lambda *_: None)
        name = get_value(f"type{index}_name")
        if not name:
            continue

        param1 = _parse_int(get_value(f"type{index}_param1"), 0)
        param2 = _parse_int(get_value(f"type{index}_param2"), DEFAULT_LIGHT_LAYOUT["flags1"])
        param3 = _parse_int(get_value(f"type{index}_param3"), 0)
        light_types.append(
            {
                "identifier": f"{SAPARTICLE_LIGHT_TYPE_PREFIX}{index}",
                "index": index,
                "name": name,
                "description": f"saparticle.ini lighttype #{index}",
                "params": (param1, param2, param3),
                "layout": _layout_from_saparticle_light_type(param1, param2, param3),
            }
        )

    default_cache["textures"] = textures or default_cache["textures"]
    default_cache["light_types"] = light_types
    default_cache["defaults"]["light"] = {
        "corona_index": _parse_int(getattr(last_light, "get", lambda *_: None)("corona"), default_cache["defaults"]["light"]["corona_index"]),
        "shadow_index": _parse_int(getattr(last_light, "get", lambda *_: None)("shad"), default_cache["defaults"]["light"]["shadow_index"]),
        "distance": _parse_float(getattr(last_light, "get", lambda *_: None)("distance"), default_cache["defaults"]["light"]["distance"]),
        "outerrange": _parse_float(getattr(last_light, "get", lambda *_: None)("outerrange"), default_cache["defaults"]["light"]["outerrange"]),
        "size": _parse_float(getattr(last_light, "get", lambda *_: None)("size"), default_cache["defaults"]["light"]["size"]),
        "innerrange": _parse_float(getattr(last_light, "get", lambda *_: None)("innerrange"), default_cache["defaults"]["light"]["innerrange"]),
        "type_index": _parse_int(getattr(last_light, "get", lambda *_: None)("type"), default_cache["defaults"]["light"]["type_index"]),
    }
    default_cache["ini_path"] = str(ini_path)

    PRESET_CACHE = default_cache
    return ini_path


def _find_light_type(identifier):
    if identifier == LIGHT_TYPE_CUSTOM_BLINK:
        return {
            "identifier": LIGHT_TYPE_CUSTOM_BLINK,
            "index": CUSTOM_BLINK_CORONA_SHOW_MODE,
            "name": "CUSTOM_BLINK",
            "description": "Custom blink type controlled by the 2DFX AELS ASI runtime",
            "is_custom": True,
        }

    for light_type in PRESET_CACHE.get("light_types") or []:
        if light_type["identifier"] == identifier:
            result = dict(light_type)
            result["is_custom"] = False
            result["is_saparticle_preset"] = True
            return result

    light_type = LIGHT_TYPE_BY_IDENTIFIER.get(identifier)
    if light_type is None:
        light_type = LIGHT_TYPE_BY_IDENTIFIER["DEFAULT"]
    result = dict(light_type)
    result["is_custom"] = False
    return result


def _corona_items(_self, _context):
    textures = PRESET_CACHE["textures"] or list(FIXED_CORONA_TEXTURES)
    return [(CORONA_NONE, "No Corona Texture", "Disable the exported corona texture", 0)] + [
        (name, name, "", index + 1) for index, name in enumerate(textures)
    ]


def _shadow_items(_self, _context):
    textures = PRESET_CACHE["textures"] or list(FIXED_SHADOW_TEXTURES)
    return [(SHADOW_NONE, "No Shadow Texture", "Disable the exported shadow texture", 0)] + [
        (name, name, "", index + 1) for index, name in enumerate(textures)
    ]


def _enum_name_from_index(values, index, fallback):
    if not values:
        return fallback
    zero_based = max(1, index) - 1
    zero_based = min(zero_based, len(values) - 1)
    return values[zero_based]


def _clamp_color_channel(value):
    return max(0, min(255, int(round(value * 255.0))))


def _effective_light_color(obj):
    light = getattr(obj, "data", None)
    color = list(getattr(light, "color", (1.0, 1.0, 1.0)))
    if light is None:
        return color

    # Modern Blender builds add temperature/exposure controls; SAE only stores RGB,
    # so we bake those controls into the exported color as closely as possible.
    if getattr(light, "use_temperature", False):
        temperature_color = getattr(light, "temperature_color", None)
        if temperature_color is not None:
            color[0] *= temperature_color[0]
            color[1] *= temperature_color[1]
            color[2] *= temperature_color[2]

    exposure = getattr(light, "exposure", 0.0)
    if exposure:
        exposure_scale = math.pow(2.0, exposure)
        color = [channel * exposure_scale for channel in color]

    if not getattr(light, "normalize", True) and hasattr(light, "area"):
        try:
            area = float(light.area(matrix_world=obj.matrix_world))
        except (AttributeError, TypeError, ValueError):
            area = 1.0
        if area > 0.0:
            color = [channel * area for channel in color]

    return color


def _aels_light_runtime_enabled(props):
    return bool(getattr(props, "aels_use_runtime", False))


def _aels_light_corona_disabled(props):
    return _corona_disabled(props) or _aels_light_runtime_enabled(props)


def _aels_light_shadow_disabled(props):
    return _shadow_disabled(props) or _aels_light_runtime_enabled(props)


def _format_aels_ini_float(value):
    text = f"{float(value):.6f}"
    text = text.rstrip("0").rstrip(".")
    return text or "0"


def _format_aels_ini_bool(value):
    return "1" if value else "0"


def _sanitize_aels_pattern_text(value):
    return str(value or "").replace("\r", "\n").strip()


def _build_simple_blink_steps(props):
    on_ms = max(0, int(props.aels_flash_on_ms))
    off_ms = max(0, int(props.aels_flash_off_ms))
    steps = []
    if on_ms > 0 or (on_ms == 0 and off_ms == 0):
        steps.append({"enabled": True, "duration_ms": on_ms})
    if off_ms > 0:
        steps.append({"enabled": False, "duration_ms": off_ms})
    return steps


def _parse_manual_blink_steps(pattern_text, start_on=True):
    pattern_text = _sanitize_aels_pattern_text(pattern_text)
    if not pattern_text:
        raise ValueError("manual pattern is empty")

    tokens = [token.strip() for token in re.split(r"[,\n;|]+", pattern_text) if token.strip()]
    if not tokens:
        raise ValueError("manual pattern does not contain any steps")

    steps = []
    enabled = bool(start_on)
    for index, token in enumerate(tokens, start=1):
        match = AELS_PATTERN_TOKEN_RE.match(token)
        if match is None:
            raise ValueError(f"invalid pattern step #{index}: '{token}'")

        duration_ms = int(match.group(1))
        if duration_ms < 0:
            raise ValueError(f"negative duration in step #{index}")

        steps.append({"enabled": enabled, "duration_ms": duration_ms})
        enabled = not enabled

    return steps


def _build_blink_timeline(props):
    pattern_text = _sanitize_aels_pattern_text(getattr(props, "aels_custom_pattern", ""))
    if not pattern_text:
        pattern_text = DEFAULT_AELS_PATTERN

    steps = _parse_manual_blink_steps(
        pattern_text,
        start_on=bool(getattr(props, "custom_blink_start_on", True)),
    )

    normalized_steps = [
        {
            "index": index,
            "enabled": bool(step["enabled"]),
            "state": "ON" if step["enabled"] else "OFF",
            "duration_ms": int(step["duration_ms"]),
        }
        for index, step in enumerate(steps, start=1)
    ]
    cycle_length_ms = sum(step["duration_ms"] for step in normalized_steps)
    active_total_ms = sum(step["duration_ms"] for step in normalized_steps if step["enabled"])
    inactive_total_ms = cycle_length_ms - active_total_ms
    simple_flash_on_ms = next((step["duration_ms"] for step in normalized_steps if step["enabled"]), 0)
    simple_flash_off_ms = next((step["duration_ms"] for step in normalized_steps if not step["enabled"]), 0)

    return {
        "mode": AELS_BLINK_MODE_PATTERN,
        "pattern_text": pattern_text,
        "phase_offset_ms": int(props.aels_phase_offset_ms),
        "simple_flash_on_ms": int(simple_flash_on_ms),
        "simple_flash_off_ms": int(simple_flash_off_ms),
        "cycle_length_ms": int(cycle_length_ms),
        "active_total_ms": int(active_total_ms),
        "inactive_total_ms": int(inactive_total_ms),
        "steps": normalized_steps,
    }


def _build_fixed_blink_timeline(mode, steps, phase_offset_ms=0):
    normalized_steps = [
        {
            "index": index,
            "enabled": bool(enabled),
            "state": "ON" if enabled else "OFF",
            "duration_ms": int(max(0, duration_ms)),
        }
        for index, (enabled, duration_ms) in enumerate(steps, start=1)
    ]
    if not normalized_steps:
        normalized_steps = [{"index": 1, "enabled": False, "state": "OFF", "duration_ms": 1000}]

    cycle_length_ms = sum(step["duration_ms"] for step in normalized_steps)
    active_total_ms = sum(step["duration_ms"] for step in normalized_steps if step["enabled"])
    inactive_total_ms = cycle_length_ms - active_total_ms
    first_on = next((step["duration_ms"] for step in normalized_steps if step["enabled"]), 0)
    first_off = next((step["duration_ms"] for step in normalized_steps if not step["enabled"]), 0)

    return {
        "mode": mode,
        "pattern_text": "",
        "phase_offset_ms": int(phase_offset_ms),
        "simple_flash_on_ms": int(first_on),
        "simple_flash_off_ms": int(first_off),
        "cycle_length_ms": int(cycle_length_ms),
        "active_total_ms": int(active_total_ms),
        "inactive_total_ms": int(inactive_total_ms),
        "steps": normalized_steps,
    }


def _stable_light_phase_offset_ms(obj, cycle_length_ms):
    if cycle_length_ms <= 0:
        return 0

    seed_text = getattr(obj, "name", "")
    seed = sum((index + 1) * ord(char) for index, char in enumerate(seed_text))
    translation = _local_translation(obj)
    seed += int(abs(translation.x) * 1000.0)
    seed += int(abs(translation.y) * 2000.0)
    seed += int(abs(translation.z) * 3000.0)
    return seed % cycle_length_ms


def _build_standard_light_timeline(obj, light_identifier):
    patterns = {
        "DEFAULT": ((True, 1000),),
        "RANDOM_FLASHING": ((True, 120), (False, 880)),
        "RANDOM_FLASHIN_ALWAYS_AT_WET_WEATHER": ((True, 120), (False, 880)),
        "LIGHTS_ANIM_SPEED_4X": ((True, 125), (False, 125)),
        "LIGHTS_ANIM_SPEED_2X": ((True, 250), (False, 250)),
        "LIGHTS_ANIM_SPEED_1X": ((True, 500), (False, 500)),
        "WARNLIGHT": ((True, 250), (False, 250)),
        "TRAFFICLIGHT": ((True, 1000),),
        "TRAINCROSSLIGHT": ((True, 500), (False, 500)),
        "DISABLED": ((False, 1000),),
        "AT_RAIN_ONLY": ((True, 1000),),
        "MODE_5S_ON_5S_OFF": ((True, 5000), (False, 5000)),
        "MODE_6S_ON_4S_OFF": ((True, 6000), (False, 4000)),
        "MODE_6S_ON_4S_OFF_2": ((False, 6000), (True, 4000)),
    }
    steps = patterns.get(light_identifier, patterns["DEFAULT"])
    cycle_length_ms = sum(duration_ms for _enabled, duration_ms in steps)
    phase_offset_ms = 0
    if light_identifier.startswith("RANDOM_FLASH"):
        phase_offset_ms = _stable_light_phase_offset_ms(obj, cycle_length_ms)
    return _build_fixed_blink_timeline("STANDARD", steps, phase_offset_ms)


def _aels_preview_tag_redraw():
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return

    for window in getattr(window_manager, "windows", []):
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in getattr(screen, "areas", []):
            if getattr(area, "type", None) == "VIEW_3D":
                area.tag_redraw()


def _aels_preview_any_enabled():
    for scene in getattr(bpy.data, "scenes", []):
        settings = getattr(scene, "defacto_2dfx_variants", None)
        if settings is not None and bool(getattr(settings, "preview_enabled", False)):
            return True
    return False


def _aels_preview_remove_handler():
    global _AELS_PREVIEW_DRAW_HANDLE
    if _AELS_PREVIEW_DRAW_HANDLE is None:
        return

    try:
        bpy.types.SpaceView3D.draw_handler_remove(_AELS_PREVIEW_DRAW_HANDLE, "WINDOW")
    except Exception:
        pass
    _AELS_PREVIEW_DRAW_HANDLE = None


def _aels_preview_timer():
    global _AELS_PREVIEW_TIMER_ACTIVE
    if not _AELS_PREVIEW_TIMER_ACTIVE or not _aels_preview_any_enabled():
        _AELS_PREVIEW_TIMER_ACTIVE = False
        _aels_preview_remove_handler()
        return None

    _aels_preview_tag_redraw()
    return 1.0 / AELS_PREVIEW_DRAW_FPS


def _aels_preview_ensure():
    global _AELS_PREVIEW_DRAW_HANDLE, _AELS_PREVIEW_TIMER_ACTIVE
    if gpu is None or batch_for_shader is None:
        return

    if not _aels_preview_any_enabled():
        _aels_preview_remove_handler()
        return

    if _AELS_PREVIEW_DRAW_HANDLE is None:
        _AELS_PREVIEW_DRAW_HANDLE = bpy.types.SpaceView3D.draw_handler_add(
            _aels_preview_draw,
            (),
            "WINDOW",
            "POST_VIEW",
        )

    if not _AELS_PREVIEW_TIMER_ACTIVE:
        _AELS_PREVIEW_TIMER_ACTIVE = True
        bpy.app.timers.register(_aels_preview_timer, first_interval=1.0 / AELS_PREVIEW_DRAW_FPS)


def _aels_preview_settings_update(_self, _context):
    _aels_preview_invalidate_cache()
    _aels_preview_ensure()
    _aels_preview_tag_redraw()


def _aels_preview_invalidate_cache():
    _AELS_PREVIEW_CACHE["rebuilt_at"] = 0.0


def _aels_preview_current_level(settings):
    if not bool(getattr(settings, "preview_follow_active_variant", True)):
        return max(VARIANT_LEVEL_NONE, min(MAX_VARIANT_LEVELS, int(getattr(settings, "preview_level", 0))))

    if bool(getattr(settings, "enabled", False)):
        level = _active_variant_level(settings)
        if level is not None:
            return max(VARIANT_LEVEL_NONE, min(MAX_VARIANT_LEVELS, int(level.level_index)))

    return VARIANT_LEVEL_NONE


def _aels_preview_light_matches_level(props, preview_level):
    if preview_level == VARIANT_LEVEL_NONE:
        return True
    light_level = max(VARIANT_LEVEL_NONE, int(getattr(props, "variant_level", VARIANT_LEVEL_NONE)))
    return light_level in {VARIANT_LEVEL_NONE, preview_level}


def _aels_preview_timeline_state_at(timeline, now_ms):
    steps = list(timeline.get("steps") or [])
    if not steps:
        return False

    cycle_length_ms = int(timeline.get("cycle_length_ms", 0))
    if cycle_length_ms <= 0:
        return any(bool(step.get("enabled", False)) for step in steps)

    tick = (int(now_ms) + int(timeline.get("phase_offset_ms", 0))) % cycle_length_ms
    elapsed_ms = 0
    last_enabled = False
    for step in steps:
        duration_ms = max(0, int(step.get("duration_ms", 0)))
        last_enabled = bool(step.get("enabled", False))
        if duration_ms <= 0:
            continue
        if tick < elapsed_ms + duration_ms:
            return last_enabled
        elapsed_ms += duration_ms
    return last_enabled


def _aels_preview_light_timeline(obj, props):
    try:
        return _build_blink_timeline(props)
    except (TypeError, ValueError):
        light_identifier = getattr(props, "light_type", "DEFAULT")
        return _build_standard_light_timeline(obj, light_identifier)


def _aels_preview_color_key(color, alpha, point_size):
    clamped = tuple(max(0.0, min(1.0, float(channel))) for channel in color[:3])
    return (
        int(point_size),
        round(clamped[0], 3),
        round(clamped[1], 3),
        round(clamped[2], 3),
        round(max(0.0, min(1.0, float(alpha))), 3),
    )


def _aels_preview_cached_light_objects(scene, now_seconds):
    object_count = len(scene.objects)
    cache_stale = (
        _AELS_PREVIEW_CACHE["scene"] != scene
        or _AELS_PREVIEW_CACHE["object_count"] != object_count
        or now_seconds - float(_AELS_PREVIEW_CACHE["rebuilt_at"]) >= AELS_PREVIEW_CACHE_SECONDS
    )
    if not cache_stale:
        return _AELS_PREVIEW_CACHE["objects"]

    objects = []
    for obj in scene.objects:
        try:
            obj_type = obj.type
        except ReferenceError:
            continue
        if obj_type != "LIGHT":
            continue

        props = getattr(obj, "defacto_2dfx", None)
        if props is None or getattr(props, "effect_kind", EFFECT_NONE) != EFFECT_LIGHT:
            continue
        objects.append(obj)

    _AELS_PREVIEW_CACHE["scene"] = scene
    _AELS_PREVIEW_CACHE["object_count"] = object_count
    _AELS_PREVIEW_CACHE["rebuilt_at"] = now_seconds
    _AELS_PREVIEW_CACHE["objects"] = objects
    return objects


def _aels_preview_collect(scene, settings):
    preview_level = _aels_preview_current_level(settings)
    show_inactive = bool(getattr(settings, "preview_show_inactive", False))
    siren_active = bool(getattr(settings, "preview_siren_active", True))
    max_lights = max(1, min(512, int(getattr(settings, "preview_max_lights", AELS_PREVIEW_MAX_LIGHTS_DEFAULT))))
    base_point_size = max(2, min(64, int(getattr(settings, "preview_point_size", 14))))
    now_seconds = time.perf_counter()
    now_ms = int(now_seconds * 1000.0)

    groups = {}
    collected = 0
    for obj in _aels_preview_cached_light_objects(scene, now_seconds):
        if collected >= max_lights:
            break
        try:
            props = getattr(obj, "defacto_2dfx", None)
        except ReferenceError:
            continue
        if not _aels_preview_light_matches_level(props, preview_level):
            continue
        if float(getattr(props, "light_size", 0.0)) <= 0.0 or int(getattr(props, "light_color_alpha", 0)) <= 0:
            continue

        timeline = _aels_preview_light_timeline(obj, props)
        is_on = _aels_preview_timeline_state_at(timeline, now_ms)
        if bool(getattr(props, "aels_requires_siren", False)) and not siren_active:
            is_on = False
        if not is_on and not show_inactive:
            continue

        color = _effective_light_color(obj)
        alpha = max(0.05, min(1.0, int(getattr(props, "light_color_alpha", 200)) / 255.0))
        if not is_on:
            alpha *= 0.18

        size_scale = math.sqrt(max(0.25, float(getattr(props, "light_size", 5.0)) / 5.0))
        point_size = max(2, min(96, int(round(base_point_size * size_scale))))
        key = _aels_preview_color_key(color, alpha, point_size)
        groups.setdefault(key, []).append(tuple(obj.matrix_world.translation))
        collected += 1

    return groups


def _aels_preview_shader():
    global _AELS_PREVIEW_SHADER
    if gpu is None:
        return None
    if _AELS_PREVIEW_SHADER is not None:
        return _AELS_PREVIEW_SHADER

    for shader_name in ("UNIFORM_COLOR", "3D_UNIFORM_COLOR"):
        try:
            _AELS_PREVIEW_SHADER = gpu.shader.from_builtin(shader_name)
            return _AELS_PREVIEW_SHADER
        except Exception:
            continue
    return None


def _aels_preview_draw():
    context = bpy.context
    scene = getattr(context, "scene", None)
    if scene is None:
        return

    settings = getattr(scene, "defacto_2dfx_variants", None)
    if settings is None or not bool(getattr(settings, "preview_enabled", False)):
        return

    shader = _aels_preview_shader()
    if shader is None or batch_for_shader is None:
        return

    try:
        groups = _aels_preview_collect(scene, settings)
        if not groups:
            return

        try:
            gpu.state.blend_set("ALPHA")
            gpu.state.depth_test_set("NONE")
        except Exception:
            pass

        shader.bind()
        for key, positions in groups.items():
            point_size, red, green, blue, alpha = key
            if not positions:
                continue
            try:
                gpu.state.point_size_set(point_size)
            except Exception:
                pass
            batch = batch_for_shader(shader, "POINTS", {"pos": positions})
            shader.uniform_float("color", (red, green, blue, alpha))
            batch.draw(shader)
    except Exception:
        _aels_preview_remove_handler()
    finally:
        try:
            gpu.state.point_size_set(1)
            gpu.state.depth_test_set("NONE")
            gpu.state.blend_set("NONE")
        except Exception:
            pass


def build_aels_ini_text(objects):
    metadata = build_aels_metadata(objects)
    if metadata is None:
        raise ValueError("No AELS light objects found to export")

    lines = [
        "; 2DFX AELS runtime export",
        "; This file is optional. All AELS runtime settings are also embedded into the DFF when enabled.",
        "[aels]",
        f"format={metadata['format']}",
        f"schema_version={metadata['schema_version']}",
        f"light_count={len(metadata['lights'])}",
    ]

    for index, light in enumerate(metadata["lights"], start=1):
        aels = light["aels"]
        direction = light.get("direction_vector")
        layout = light["layout"]
        lines.extend(
            [
                "",
                f"[light_{index:03d}]",
                f"name={light['name']}",
                f"blender_light_type={light['blender_light_type']}",
                f"vehicle_class={aels['vehicle_class']}",
                f"runtime_enabled={_format_aels_ini_bool(aels['enabled'])}",
                f"requires_siren={_format_aels_ini_bool(aels['requires_siren'])}",
                f"flash_on_ms={aels['flash_on_ms']}",
                f"flash_off_ms={aels['flash_off_ms']}",
                f"phase_offset_ms={aels['phase_offset_ms']}",
                f"blink_mode={aels['blink_mode']}",
                f"cycle_length_ms={aels['cycle_length_ms']}",
                f"pattern_step_count={len(aels['steps'])}",
                f"pattern_text={aels['pattern_text']}",
                f"export_corona={_format_aels_ini_bool(aels['export_corona'])}",
                f"corona={light['corona']}",
                f"shadow={light['shadow']}",
                f"corona_disabled={_format_aels_ini_bool(light['corona_disabled'])}",
                f"shadow_disabled={_format_aels_ini_bool(light['shadow_disabled'])}",
                f"directional={_format_aels_ini_bool(light['directional'])}",
                f"linked_objects={','.join(light.get('linked_object_names') or [])}",
                f"facing={light['facing']}",
                f"draw_distance={_format_aels_ini_float(light['draw_distance'])}",
                f"outer_range={_format_aels_ini_float(light['outer_range'])}",
                f"corona_size={_format_aels_ini_float(light['corona_size'])}",
                f"shadow_size={_format_aels_ini_float(light['shadow_size'])}",
                f"local_x={_format_aels_ini_float(light['local_position'][0])}",
                f"local_y={_format_aels_ini_float(light['local_position'][1])}",
                f"local_z={_format_aels_ini_float(light['local_position'][2])}",
                f"rot_x={_format_aels_ini_float(light['local_rotation_xyz'][0])}",
                f"rot_y={_format_aels_ini_float(light['local_rotation_xyz'][1])}",
                f"rot_z={_format_aels_ini_float(light['local_rotation_xyz'][2])}",
                f"color_linear_r={_format_aels_ini_float(light['color_rgb_linear'][0])}",
                f"color_linear_g={_format_aels_ini_float(light['color_rgb_linear'][1])}",
                f"color_linear_b={_format_aels_ini_float(light['color_rgb_linear'][2])}",
                f"color_exported_r={light['color_rgba_exported'][0]}",
                f"color_exported_g={light['color_rgba_exported'][1]}",
                f"color_exported_b={light['color_rgba_exported'][2]}",
                f"color_exported_a={light['color_rgba_exported'][3]}",
                f"layout_corona_show_mode={layout['corona_show_mode']}",
                f"layout_corona_enable_reflection={layout['corona_enable_reflection']}",
                f"layout_corona_flare_type={layout['corona_flare_type']}",
                f"layout_shadow_color_multiplier={layout['shadow_color_multiplier']}",
                f"layout_shadow_z_distance={layout['shadow_z_distance']}",
                f"layout_flags1={layout['flags1']}",
                f"layout_flags2={layout['flags2']}",
                f"layout_look_direction_x={layout['look_direction_bytes'][0]}",
                f"layout_look_direction_y={layout['look_direction_bytes'][1]}",
                f"layout_look_direction_z={layout['look_direction_bytes'][2]}",
            ]
        )
        if direction is not None:
            lines.extend(
                [
                    f"direction_x={_format_aels_ini_float(direction[0])}",
                    f"direction_y={_format_aels_ini_float(direction[1])}",
                    f"direction_z={_format_aels_ini_float(direction[2])}",
                ]
            )
        for step in aels["steps"]:
            lines.extend(
                [
                    f"pattern_step_{step['index']:02d}_state={step['state']}",
                    f"pattern_step_{step['index']:02d}_duration_ms={step['duration_ms']}",
                ]
            )

    return "\n".join(lines) + "\n"


def export_aels_ini(filepath, objects):
    Path(filepath).write_text(build_aels_ini_text(objects), encoding="utf-8", newline="\n")


def _ensure_ascii_bytes(text, max_length=None):
    value = (text or "").replace("\x00", "")
    data = value.encode("ascii", "replace")
    if max_length is not None:
        data = data[:max_length]
    return data


def _write_u32(handle, value):
    handle.write(struct.pack("<I", int(value) & 0xFFFFFFFF))


def _write_u16(handle, value):
    handle.write(struct.pack("<H", int(value) & 0xFFFF))


def _write_i32(handle, value):
    handle.write(struct.pack("<i", int(value)))


def _write_f32(handle, value):
    handle.write(struct.pack("<f", float(value)))


def _write_u8(handle, value):
    handle.write(struct.pack("<B", int(value) & 0xFF))


def _write_c_string(handle, text, max_length=None):
    handle.write(_ensure_ascii_bytes(text, max_length=max_length))
    handle.write(b"\x00")


def _write_len_ascii_string(handle, text, max_length=96):
    data = _ensure_ascii_bytes(text, max_length=max_length)
    _write_u32(handle, len(data))
    handle.write(data)


def _write_fixed_ascii_field(handle, text, field_size):
    handle.write(_ensure_ascii_bytes(text, max_length=field_size - 1).ljust(field_size, b"\x00"))


def _local_translation(obj):
    return obj.matrix_local.to_translation()


def _local_euler_xyz(obj):
    return obj.matrix_local.to_quaternion().to_euler("XYZ")


def _init_light_defaults(props):
    defaults = PRESET_CACHE["defaults"]["light"]
    textures = PRESET_CACHE["textures"] or list(FIXED_CORONA_TEXTURES)
    props.effect_kind = EFFECT_LIGHT
    props.light_draw_distance = defaults["distance"]
    props.light_outer_range = defaults["outerrange"]
    props.light_size = defaults["size"]
    props.light_inner_range = defaults["innerrange"]
    props.light_color_alpha = 200
    props.light_corona = _enum_name_from_index(textures, defaults["corona_index"], FIXED_CORONA_TEXTURES[0])
    props.light_shadow = _enum_name_from_index(textures, defaults["shadow_index"], FIXED_SHADOW_TEXTURES[0])
    props.light_type = "DEFAULT"
    props.custom_blink_interval_ms = 160
    props.custom_blink_start_on = True
    props.aels_use_runtime = True
    props.aels_requires_siren = True
    props.aels_blink_mode = AELS_BLINK_MODE_PATTERN
    props.aels_flash_on_ms = 160
    props.aels_flash_off_ms = 160
    props.aels_phase_offset_ms = 0
    props.aels_custom_pattern = DEFAULT_AELS_PATTERN
    props.aels_export_corona = False


def _collect_export_objects(context, use_selection_only):
    source = context.selected_objects if use_selection_only else context.scene.objects
    export_objects = []
    for obj in source:
        props = getattr(obj, "defacto_2dfx", None)
        if props is None or props.effect_kind == EFFECT_NONE:
            continue
        if props.effect_kind != EFFECT_LIGHT:
            continue
        if obj.type != "LIGHT":
            continue
        export_objects.append(obj)
    return export_objects


def _shadow_disabled(props):
    return props.light_shadow == SHADOW_NONE


def _corona_disabled(props):
    return props.light_corona == CORONA_NONE


def _direction_axis_vector(identifier):
    vectors = {
        LIGHT_FACE_FRONT: Vector((0.0, 1.0, 0.0)),
        LIGHT_FACE_BACK: Vector((0.0, -1.0, 0.0)),
        LIGHT_FACE_LEFT: Vector((-1.0, 0.0, 0.0)),
        LIGHT_FACE_RIGHT: Vector((1.0, 0.0, 0.0)),
        LIGHT_FACE_UP: Vector((0.0, 0.0, 1.0)),
        LIGHT_FACE_DOWN: Vector((0.0, 0.0, -1.0)),
    }
    return vectors.get(identifier, Vector((0.0, -1.0, 0.0)))


def _direction_vector_for_object(obj, facing):
    direction = obj.matrix_world.to_3x3() @ _direction_axis_vector(facing)
    if direction.length_squared == 0.0:
        return Vector((0.0, 0.0, 1.0))
    direction.normalize()
    return direction


def _signed_direction_byte(value):
    return int(max(-127, min(127, round(value * 100.0)))) & 0xFF


def _direction_bytes_for_object(obj, facing):
    # Follow the visible Blender rotation so directional corona/shadow behavior
    # matches what the user sees even when parent transforms contribute rotation.
    direction = _direction_vector_for_object(obj, facing)

    return (
        _signed_direction_byte(direction.x),
        _signed_direction_byte(direction.y),
        _signed_direction_byte(direction.z),
    )

def _find_light_type_identifier_from_index(index):
    for mode, identifier, _label, _description in LIGHT_TYPE_DEFINITIONS:
        if mode == index:
            return identifier
    return "DEFAULT"


def _is_custom_blink_light(props):
    return getattr(props, "light_type", "DEFAULT") == LIGHT_TYPE_CUSTOM_BLINK


def _is_runtime_managed_light(_props):
    return True


def _build_legacy_custom_blink_timeline(props):
    custom_interval = max(1, int(getattr(props, "custom_blink_interval_ms", 160)))
    start_on = bool(getattr(props, "custom_blink_start_on", True))
    return {
        "mode": "CUSTOM_BLINK",
        "pattern_text": "",
        "phase_offset_ms": 0,
        "simple_flash_on_ms": custom_interval,
        "simple_flash_off_ms": custom_interval,
        "cycle_length_ms": custom_interval * 2,
        "active_total_ms": custom_interval,
        "inactive_total_ms": custom_interval,
        "steps": [
            {"index": 1, "enabled": start_on, "state": "ON" if start_on else "OFF", "duration_ms": custom_interval},
            {"index": 2, "enabled": not start_on, "state": "OFF" if start_on else "ON", "duration_ms": custom_interval},
        ],
    }


def _build_light_layout(_light_data=None):
    layout = dict(DEFAULT_LIGHT_LAYOUT)
    layout["corona_show_mode"] = DEFAULT_CORONA_SHOW_MODE
    return layout


def _write_light_entry(handle, obj):
    props = obj.defacto_2dfx
    light_data = _find_light_type(getattr(props, "light_type", "DEFAULT"))
    layout = _build_light_layout(light_data)
    translation = _local_translation(obj)
    datsize = 80
    color = _effective_light_color(obj)
    runtime_managed = _is_runtime_managed_light(props)
    # Runtime lights own their corona drawing, but the legacy shadow still needs
    # to be exported so "shadow without corona" continues to work from the DFF.
    corona_disabled = _corona_disabled(props) or runtime_managed
    shadow_disabled = _shadow_disabled(props)
    corona_name = "" if corona_disabled else props.light_corona
    corona_size = 0.0 if corona_disabled else props.light_size
    shadow_name = "" if shadow_disabled else props.light_shadow
    shadow_size = 0.0 if shadow_disabled else props.light_inner_range
    shadow_color_multiplier = 0 if shadow_disabled else layout["shadow_color_multiplier"]
    shadow_z_distance = 0 if shadow_disabled else layout["shadow_z_distance"]
    flags1 = layout["flags1"]
    flags2 = layout["flags2"]
    look_direction_x = layout["look_direction_x"]
    look_direction_y = layout["look_direction_y"]
    look_direction_z = layout["look_direction_z"]

    if corona_disabled:
        flags1 |= 0x08

    if props.light_directional:
        flags2 |= 0x08
        look_direction_x, look_direction_y, look_direction_z = _direction_bytes_for_object(
            obj,
            props.light_facing,
        )

    _write_f32(handle, translation.x)
    _write_f32(handle, translation.y)
    _write_f32(handle, translation.z)
    _write_u32(handle, 0x00)
    _write_u32(handle, datsize)

    _write_u8(handle, _clamp_color_channel(color[0]))
    _write_u8(handle, _clamp_color_channel(color[1]))
    _write_u8(handle, _clamp_color_channel(color[2]))
    _write_u8(handle, props.light_color_alpha)
    _write_f32(handle, props.light_draw_distance)
    _write_f32(handle, props.light_outer_range)
    _write_f32(handle, corona_size)
    _write_f32(handle, shadow_size)
    _write_u8(handle, layout["corona_show_mode"])
    _write_u8(handle, layout["corona_enable_reflection"])
    _write_u8(handle, layout["corona_flare_type"])
    _write_u8(handle, shadow_color_multiplier)
    _write_u8(handle, flags1)
    _write_fixed_ascii_field(handle, corona_name, 24)
    _write_fixed_ascii_field(handle, shadow_name, 24)
    _write_u8(handle, shadow_z_distance)
    _write_u8(handle, flags2)
    _write_u8(handle, look_direction_x)
    _write_u8(handle, look_direction_y)
    _write_u8(handle, look_direction_z)
    _write_u8(handle, 0)
    _write_u8(handle, 0)


def export_sae(filepath, objects):
    Path(filepath).write_bytes(build_sae_bytes(objects))


def build_sae_bytes(objects):
    light_objects = [
        obj
        for obj in objects
        if getattr(getattr(obj, "defacto_2dfx", None), "effect_kind", EFFECT_NONE) == EFFECT_LIGHT and obj.type == "LIGHT"
    ]
    handle = io.BytesIO()
    _write_u32(handle, len(light_objects))
    for obj in light_objects:
        _write_light_entry(handle, obj)
    return handle.getvalue()


def _runtime_record_from_object(obj):
    props = obj.defacto_2dfx
    if not _is_custom_blink_light(props):
        return None

    translation = _local_translation(obj)
    color = _effective_light_color(obj)
    return {
        "local_position": (
            float(translation.x),
            float(translation.y),
            float(translation.z),
        ),
        "color_rgba": (
            _clamp_color_channel(color[0]),
            _clamp_color_channel(color[1]),
            _clamp_color_channel(color[2]),
            int(props.light_color_alpha),
        ),
        "size": 0.0 if _corona_disabled(props) else float(max(0.0, props.light_size)),
        "blink_interval_ms": int(max(1, props.custom_blink_interval_ms)),
        "start_on": bool(props.custom_blink_start_on),
    }


def build_runtime_records(objects):
    records = []
    for obj in objects:
        if obj.type != "LIGHT":
            continue
        if getattr(obj.defacto_2dfx, "effect_kind", EFFECT_NONE) != EFFECT_LIGHT:
            continue
        record = _runtime_record_from_object(obj)
        if record is not None:
            records.append(record)
    return records


def _infer_gta_root_from_path(filepath):
    path = Path(filepath).resolve()
    search_path = path if path.is_dir() else path.parent
    for candidate in (search_path, *search_path.parents):
        if (candidate / "gta_sa.exe").exists():
            return candidate
    return None


def _iter_vehicle_ide_paths(game_root):
    preferred = game_root / "data" / "vehicles.ide"
    if preferred.exists():
        yield preferred

    data_dir = game_root / "data"
    if not data_dir.exists():
        return

    for path in sorted(data_dir.rglob("*.ide")):
        if path == preferred:
            continue
        yield path


def _load_vehicle_model_ids(game_root):
    cache_key = str(Path(game_root).resolve()).lower()
    cached = MODEL_ID_CACHE.get(cache_key)
    if cached is not None:
        return cached

    model_ids = {}
    for ide_path in _iter_vehicle_ide_paths(Path(game_root)):
        try:
            text = ide_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        for raw_line in text.splitlines():
            line = raw_line.split("#", 1)[0].strip()
            if not line or "," not in line:
                continue

            parts = [part.strip() for part in line.split(",")]
            if len(parts) < 2:
                continue

            try:
                model_id = int(parts[0])
            except ValueError:
                continue

            model_name = parts[1].lower()
            if model_name and model_name not in model_ids:
                model_ids[model_name] = model_id

    MODEL_ID_CACHE[cache_key] = model_ids
    return model_ids


def _resolve_model_id_for_dff(dff_path, game_root):
    model_name = Path(dff_path).stem.lower()
    return _load_vehicle_model_ids(game_root).get(model_name)


def _pack_runtime_db(model_records):
    handle = io.BytesIO()
    handle.write(RUNTIME_DB_MAGIC)
    _write_u32(handle, RUNTIME_DB_VERSION)
    _write_u32(handle, len(model_records))

    for model_id in sorted(model_records):
        records = model_records[model_id]
        _write_u32(handle, model_id)
        _write_u32(handle, len(records))
        for record in records:
            _write_f32(handle, record["local_position"][0])
            _write_f32(handle, record["local_position"][1])
            _write_f32(handle, record["local_position"][2])
            _write_u8(handle, record["color_rgba"][0])
            _write_u8(handle, record["color_rgba"][1])
            _write_u8(handle, record["color_rgba"][2])
            _write_u8(handle, record["color_rgba"][3])
            _write_f32(handle, record["size"])
            _write_u32(handle, record["blink_interval_ms"])
            _write_u32(handle, 1 if record["start_on"] else 0)

    return handle.getvalue()


def _unpack_runtime_db(data):
    if len(data) < 12 or data[:4] != RUNTIME_DB_MAGIC:
        return {}

    version = struct.unpack_from("<I", data, 4)[0]
    if version != RUNTIME_DB_VERSION:
        return {}

    model_count = struct.unpack_from("<I", data, 8)[0]
    offset = 12
    records = {}

    for _index in range(model_count):
        if offset + 8 > len(data):
            break

        model_id, light_count = struct.unpack_from("<II", data, offset)
        offset += 8
        model_lights = []

        for _light_index in range(light_count):
            if offset + RUNTIME_LIGHT_RECORD_SIZE > len(data):
                offset = len(data)
                break

            local_x, local_y, local_z = struct.unpack_from("<fff", data, offset)
            offset += 12
            rgba = struct.unpack_from("<BBBB", data, offset)
            offset += 4
            size = struct.unpack_from("<f", data, offset)[0]
            offset += 4
            blink_interval_ms = struct.unpack_from("<I", data, offset)[0]
            offset += 4
            start_on = bool(struct.unpack_from("<I", data, offset)[0])
            offset += 4

            model_lights.append(
                {
                    "local_position": (local_x, local_y, local_z),
                    "color_rgba": rgba,
                    "size": size,
                    "blink_interval_ms": blink_interval_ms,
                    "start_on": start_on,
                }
            )

        records[model_id] = model_lights

    return records


def _load_runtime_db(db_path):
    path = Path(db_path)
    if not path.exists():
        return {}
    try:
        return _unpack_runtime_db(path.read_bytes())
    except OSError:
        return {}


def _save_runtime_db(db_path, model_records):
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(_pack_runtime_db(model_records))


def update_runtime_db_for_dff(dff_path, objects):
    game_root = _infer_gta_root_from_path(dff_path)
    if game_root is None:
        return {"updated": False, "reason": "game_root_not_found", "db_path": ""}

    model_id = _resolve_model_id_for_dff(dff_path, game_root)
    if model_id is None:
        return {"updated": False, "reason": "model_id_not_found", "db_path": str(game_root / "CLEO" / "2DFX_AELS.dat")}

    db_path = game_root / "CLEO" / "2DFX_AELS.dat"
    model_records = _load_runtime_db(db_path)
    runtime_records = build_runtime_records(objects)
    model_records[model_id] = runtime_records
    _save_runtime_db(db_path, model_records)
    return {
        "updated": True,
        "reason": "ok",
        "db_path": str(db_path),
        "model_id": model_id,
        "light_count": len(runtime_records),
    }


def _round_float(value, digits=6):
    return round(float(value), digits)


def _vector_to_list(vector, digits=6):
    return [_round_float(component, digits=digits) for component in vector]


def _variant_scene_props_from_objects(objects):
    for obj in objects:
        scene = getattr(obj, "users_scene", None)
        if scene:
            props = getattr(scene[0], "defacto_2dfx_variants", None)
            if props is not None:
                return props
    scene = getattr(bpy.context, "scene", None)
    return getattr(scene, "defacto_2dfx_variants", None) if scene is not None else None


def _active_variant_levels_from_props(variant_props):
    if variant_props is None or not getattr(variant_props, "enabled", False):
        return []
    return [level for level in variant_props.levels if getattr(level, "enabled", True)]


def _variant_level_export_id(level):
    return int(getattr(level, "level_index", 0))


def _extra_id_from_object_name(name):
    normalized = _normalize_extra_object_name(name)
    match = re.match(r"^(?:extra|extr|misc)([1-6])", normalized)
    return int(match.group(1)) if match else 0


def _variant_object_export_name(name):
    value = str(name or "").strip().replace("\x00", "")
    value = re.sub(r"\.\d{3}$", "", value)
    return value[:96]


def _linked_light_object_export_name(name):
    value = str(name or "").strip().replace("\x00", "")
    return value[:96]


def _linked_light_object_export_names(obj):
    props = getattr(obj, "defacto_2dfx", None)
    if props is None:
        return []

    linked_obj = getattr(props, "linked_light_object", None)
    if linked_obj is None or getattr(linked_obj, "type", "") != "MESH":
        return []

    names = []
    object_name = _linked_light_object_export_name(linked_obj.name)
    stripped_object_name = _variant_object_export_name(linked_obj.name)
    data_name = _linked_light_object_export_name(getattr(getattr(linked_obj, "data", None), "name", ""))
    stripped_data_name = _variant_object_export_name(getattr(getattr(linked_obj, "data", None), "name", ""))

    for candidate in (
        object_name,
        stripped_object_name,
        data_name,
        stripped_data_name,
    ):
        normalized = _normalize_extra_object_name(candidate)
        if not candidate or not normalized:
            continue
        if candidate not in names:
            names.append(candidate)
    return names


def _variant_extra_level_export_id(obj):
    props = getattr(obj, "defacto_2dfx", None)
    if props is None:
        return VARIANT_LEVEL_NONE
    return max(VARIANT_LEVEL_NONE, int(getattr(props, "variant_extra_level", VARIANT_LEVEL_NONE)))


def _variant_extra_mask(level, objects=None):
    mask = 0
    level_id = _variant_level_export_id(level)
    search_objects = list(objects or [])
    scene = getattr(bpy.context, "scene", None)
    if scene is not None:
        for obj in scene.objects:
            if obj not in search_objects:
                search_objects.append(obj)

    for obj in search_objects:
        if _variant_extra_level_export_id(obj) != level_id:
            continue
        extra_id = _extra_id_from_object_name(obj.name)
        if 1 <= extra_id <= 6:
            mask |= 1 << (extra_id - 1)
    return mask


def _variant_extra_ids_from_mask(mask):
    return [index + 1 for index in range(6) if int(mask) & (1 << index)]


def _variant_object_names(level, objects=None):
    level_id = _variant_level_export_id(level)
    search_objects = list(objects or [])
    scene = getattr(bpy.context, "scene", None)
    if scene is not None:
        for obj in scene.objects:
            if obj not in search_objects:
                search_objects.append(obj)

    names = []
    seen = set()
    for obj in search_objects:
        if _variant_extra_level_export_id(obj) != level_id:
            continue
        name = _variant_object_export_name(obj.name)
        key = _normalize_extra_object_name(name)
        if not name or not key or key in seen:
            continue
        seen.add(key)
        names.append(name)
    return names


def _light_variant_level_export_id(obj):
    props = getattr(obj, "defacto_2dfx", None)
    if props is None:
        return VARIANT_LEVEL_NONE
    return max(VARIANT_LEVEL_NONE, int(getattr(props, "variant_level", VARIANT_LEVEL_NONE)))


def _build_light_aels_entry(obj):
    props = obj.defacto_2dfx
    layout = _build_light_layout()
    runtime_enabled = True
    blink_timeline = _build_blink_timeline(props)
    legacy_corona_disabled = _corona_disabled(props) or runtime_enabled
    legacy_shadow_disabled = _shadow_disabled(props)
    legacy_exported = False
    color = _effective_light_color(obj)
    translation = _local_translation(obj)
    rotation = _local_euler_xyz(obj)
    shadow_color_multiplier = 0 if legacy_shadow_disabled else layout["shadow_color_multiplier"]
    shadow_z_distance = 0 if legacy_shadow_disabled else layout["shadow_z_distance"]
    flags1 = layout["flags1"]
    flags2 = layout["flags2"]
    look_direction = (
        layout["look_direction_x"],
        layout["look_direction_y"],
        layout["look_direction_z"],
    )
    direction_vector = None

    if legacy_corona_disabled:
        flags1 |= 0x08

    if props.light_directional:
        flags2 |= 0x08
        look_direction = _direction_bytes_for_object(obj, props.light_facing)
        direction_vector = _direction_vector_for_object(obj, props.light_facing)

    return {
        "name": obj.name,
        "blender_light_type": getattr(getattr(obj, "data", None), "type", ""),
        "local_position": _vector_to_list(translation),
        "local_rotation_xyz": _vector_to_list(rotation),
        "color_rgb_linear": [_round_float(channel) for channel in color[:3]],
        "color_rgba_exported": [
            _clamp_color_channel(color[0]),
            _clamp_color_channel(color[1]),
            _clamp_color_channel(color[2]),
            int(props.light_color_alpha),
        ],
        "draw_distance": _round_float(props.light_draw_distance),
        "outer_range": _round_float(props.light_outer_range),
        "corona_size": _round_float(0.0 if _corona_disabled(props) else max(0.0, props.light_size)),
        "shadow_size": _round_float(0.0 if legacy_shadow_disabled else props.light_inner_range),
        "corona": "" if legacy_corona_disabled else props.light_corona,
        "shadow": "" if legacy_shadow_disabled else props.light_shadow,
        "corona_disabled": legacy_corona_disabled,
        "shadow_disabled": legacy_shadow_disabled,
        "directional": bool(props.light_directional),
        "facing": props.light_facing,
        "direction_vector": _vector_to_list(direction_vector) if direction_vector is not None else None,
        "linked_object_names": _linked_light_object_export_names(obj),
        "variant_level": _light_variant_level_export_id(obj),
        "aels": {
            "enabled": runtime_enabled,
            "vehicle_class": "ANY_EMERGENCY",
            "requires_siren": True,
            "flash_on_ms": blink_timeline["simple_flash_on_ms"],
            "flash_off_ms": blink_timeline["simple_flash_off_ms"],
            "phase_offset_ms": blink_timeline["phase_offset_ms"],
            "blink_mode": blink_timeline["mode"],
            "pattern_text": blink_timeline["pattern_text"],
            "cycle_length_ms": blink_timeline["cycle_length_ms"],
            "active_total_ms": blink_timeline["active_total_ms"],
            "inactive_total_ms": blink_timeline["inactive_total_ms"],
            "steps": blink_timeline["steps"],
            "export_corona": legacy_exported,
        },
        "layout": {
            "corona_show_mode": int(layout["corona_show_mode"]),
            "corona_enable_reflection": int(layout["corona_enable_reflection"]),
            "corona_flare_type": int(layout["corona_flare_type"]),
            "shadow_color_multiplier": int(shadow_color_multiplier),
            "shadow_z_distance": int(shadow_z_distance),
            "flags1": int(flags1),
            "flags2": int(flags2),
            "look_direction_bytes": [int(component) for component in look_direction],
        },
    }


def build_aels_metadata(objects):
    lights = [
        _build_light_aels_entry(obj)
        for obj in objects
        if obj.defacto_2dfx.effect_kind == EFFECT_LIGHT
        and obj.type == "LIGHT"
    ]
    if not lights:
        return None

    variant_props = _variant_scene_props_from_objects(objects)
    variant_levels = _active_variant_levels_from_props(variant_props)
    variants_enabled = bool(variant_levels)

    return {
        "format": "2DFX_AELS",
        "schema_version": AELS_METADATA_VERSION,
        "lights": lights,
        "paintjob_variants": {
            "enabled": variants_enabled,
            "levels": [
                {
                    "enabled": bool(level.enabled),
                    "level": _variant_level_export_id(level),
                    "name": level.name,
                    "paintjob_index": int(level.paintjob_index),
                    "extra_mask": _variant_extra_mask(level, objects),
                    "extra_ids": _variant_extra_ids_from_mask(_variant_extra_mask(level, objects)),
                    "object_names": _variant_object_names(level, objects),
                }
                for level in variant_levels
            ],
        },
    }


def _aels_runtime_light_flags(light):
    aels = light["aels"]
    flags = 0
    if aels["enabled"]:
        flags |= AELS_BINARY_LIGHT_FLAG_ENABLED
        flags |= AELS_BINARY_LIGHT_FLAG_REQUIRES_SIREN
    if light["directional"]:
        flags |= AELS_BINARY_LIGHT_FLAG_DIRECTIONAL
    if aels["export_corona"]:
        flags |= AELS_BINARY_LIGHT_FLAG_EXPORT_LEGACY
    return flags


def _pack_aels_runtime_payload(metadata):
    handle = io.BytesIO()
    lights = metadata["lights"]
    _write_u32(handle, len(lights))

    for light in lights:
        aels = light["aels"]
        direction = light.get("direction_vector") or (0.0, 0.0, 0.0)
        _write_u32(handle, _aels_runtime_light_flags(light))
        _write_u32(handle, int(light.get("variant_level", VARIANT_LEVEL_NONE)))
        rgba = light["color_rgba_exported"]
        _write_u8(handle, int(rgba[0]))
        _write_u8(handle, int(rgba[1]))
        _write_u8(handle, int(rgba[2]))
        _write_u8(handle, int(rgba[3]))
        for component in light["local_position"]:
            _write_f32(handle, component)
        for component in direction:
            _write_f32(handle, component)
        _write_f32(handle, light["draw_distance"])
        _write_f32(handle, light["outer_range"])
        _write_f32(handle, light["corona_size"])
        _write_i32(handle, aels["phase_offset_ms"])
        _write_u32(handle, len(aels["steps"]))
        for step in aels["steps"]:
            _write_u32(handle, int(step["duration_ms"]))
            _write_u32(handle, 1 if step["enabled"] else 0)
        linked_object_names = list(light.get("linked_object_names") or [])
        _write_u32(handle, len(linked_object_names))
        for object_name in linked_object_names:
            _write_len_ascii_string(handle, object_name)

    variants = metadata.get("paintjob_variants") or {}
    levels = variants.get("levels") or []
    _write_u32(handle, 1 if variants.get("enabled") and levels else 0)
    _write_u32(handle, len(levels))
    for level in levels:
        _write_u32(handle, int(level.get("level", VARIANT_LEVEL_NONE)))
        _write_i32(handle, int(level.get("paintjob_index", -1)))
        _write_u32(handle, int(level.get("extra_mask", 0)) & 0x3F)
        object_names = list(level.get("object_names") or [])
        _write_u32(handle, len(object_names))
        for object_name in object_names:
            _write_len_ascii_string(handle, object_name)

    return handle.getvalue()


def _unpack_aels_runtime_payload(data, version=AELS_METADATA_VERSION):
    offset = 0
    data_length = len(data)

    def _require(size):
        if offset + size > data_length:
            raise ValueError("AELS binary payload is truncated")

    def _read_u32():
        nonlocal offset
        _require(4)
        value = struct.unpack_from("<I", data, offset)[0]
        offset += 4
        return value

    def _read_i32():
        nonlocal offset
        _require(4)
        value = struct.unpack_from("<i", data, offset)[0]
        offset += 4
        return value

    def _read_f32():
        nonlocal offset
        _require(4)
        value = struct.unpack_from("<f", data, offset)[0]
        offset += 4
        return value

    def _read_u8():
        nonlocal offset
        _require(1)
        value = data[offset]
        offset += 1
        return value

    def _read_string():
        nonlocal offset
        length = _read_u32()
        if length > 4096:
            raise ValueError("AELS binary string is too long")
        _require(length)
        value = data[offset : offset + length].decode("ascii", errors="ignore")
        offset += length
        return value

    light_count = _read_u32()
    lights = []

    for light_index in range(light_count):
        flags = _read_u32()
        variant_level = _read_u32()
        rgba = [_read_u8(), _read_u8(), _read_u8(), _read_u8()]
        local_position = [_read_f32(), _read_f32(), _read_f32()]
        direction = [_read_f32(), _read_f32(), _read_f32()]
        draw_distance = _read_f32()
        outer_range = _read_f32()
        corona_size = _read_f32()
        phase_offset_ms = _read_i32()
        step_count = _read_u32()
        steps = []
        for step_index in range(step_count):
            duration_ms = _read_u32()
            step_flags = _read_u32()
            enabled = bool(step_flags & 0x01)
            steps.append(
                {
                    "index": step_index + 1,
                    "enabled": enabled,
                    "state": "ON" if enabled else "OFF",
                    "duration_ms": int(duration_ms),
                }
            )
        linked_object_names = []
        if version >= 10:
            linked_object_name_count = _read_u32()
            if linked_object_name_count > 64:
                raise ValueError("AELS linked object table is too large")
            for _name_index in range(linked_object_name_count):
                object_name = _variant_object_export_name(_read_string())
                if object_name and object_name not in linked_object_names:
                    linked_object_names.append(object_name)

        lights.append(
            {
                "name": f"Light_{light_index + 1:03d}",
                "variant_level": int(variant_level),
                "local_position": local_position,
                "direction_vector": direction if any(abs(component) > 1e-6 for component in direction) else None,
                "draw_distance": draw_distance,
                "outer_range": outer_range,
                "corona_size": corona_size,
                "color_rgba_exported": rgba,
                "directional": bool(flags & AELS_BINARY_LIGHT_FLAG_DIRECTIONAL),
                "linked_object_names": linked_object_names,
                "aels": {
                    "enabled": bool(flags & AELS_BINARY_LIGHT_FLAG_ENABLED),
                    "requires_siren": bool(flags & AELS_BINARY_LIGHT_FLAG_REQUIRES_SIREN),
                    "phase_offset_ms": phase_offset_ms,
                    "steps": steps,
                    "export_corona": bool(flags & AELS_BINARY_LIGHT_FLAG_EXPORT_LEGACY),
                },
            }
        )

    variants_enabled = False
    variant_levels = []
    if offset < data_length:
        variants_enabled = bool(_read_u32())
        level_count = _read_u32()
        for _level_index in range(level_count):
            level = _read_u32()
            paintjob_index = _read_i32()
            extra_mask = _read_u32()
            object_names = []
            if version >= 9:
                object_name_count = _read_u32()
                for _name_index in range(object_name_count):
                    object_name = _read_string()
                    if object_name:
                        object_names.append(object_name)
            variant_levels.append(
                {
                    "level": int(level),
                    "name": f"Level {level}",
                    "paintjob_index": int(paintjob_index),
                    "extra_mask": int(extra_mask),
                    "extra_ids": _variant_extra_ids_from_mask(extra_mask),
                    "object_names": object_names,
                }
            )

    return {
        "format": "2DFX_AELS",
        "schema_version": AELS_METADATA_VERSION,
        "lights": lights,
        "paintjob_variants": {
            "enabled": variants_enabled,
            "levels": variant_levels,
        },
    }


def build_aels_metadata_bytes(objects):
    metadata = build_aels_metadata(objects)
    if metadata is None:
        return None

    payload = _pack_aels_runtime_payload(metadata)
    return AELS_METADATA_MAGIC + struct.pack("<II", AELS_METADATA_VERSION, len(payload)) + payload


def parse_aels_metadata_bytes(payload):
    if len(payload) < 12:
        raise ValueError("AELS payload is truncated")
    if payload[:4] != AELS_METADATA_MAGIC:
        raise ValueError("Invalid AELS payload header")

    version, size = struct.unpack_from("<II", payload, 4)
    data_end = 12 + size
    if len(payload) < data_end:
        raise ValueError("AELS payload JSON is truncated")

    data = payload[12:data_end]
    if version <= 3:
        metadata = json.loads(data.decode("utf-8"))
        metadata.setdefault("schema_version", version)
        return metadata
    if version not in (8, 9, AELS_METADATA_VERSION):
        raise ValueError(f"Unsupported AELS payload version: {version}")

    return _unpack_aels_runtime_payload(data, version=version)


def _pack_rw_chunk(chunk_id, version, payload):
    return struct.pack("<III", int(chunk_id), len(payload), int(version)) + payload


def _split_rw_chunks(data):
    chunks = []
    offset = 0
    data_length = len(data)
    while offset < data_length:
        remaining = data_length - offset
        if remaining < 12:
            tail = data[offset:]
            if any(tail):
                raise ValueError(
                    f"Incomplete RenderWare chunk header at offset {offset} "
                    f"({remaining} trailing byte(s))"
                )
            break

        chunk_id, size, version = struct.unpack_from("<III", data, offset)
        if chunk_id == 0 and size == 0 and version == 0:
            tail = data[offset:]
            if any(tail):
                raise ValueError(
                    f"Unexpected zeroed RenderWare chunk header at offset {offset}"
                )
            break

        header_end = offset + 12
        chunk_end = header_end + size
        if chunk_end > data_length:
            raise ValueError(
                f"RenderWare chunk size exceeds container bounds at offset {offset}"
            )

        chunks.append(
            {
                "id": chunk_id,
                "size": size,
                "version": version,
                "start": offset,
                "payload_start": header_end,
                "end": chunk_end,
                "payload": data[header_end:chunk_end],
            }
        )
        offset = chunk_end

    return chunks, data[offset:]


def _iter_rw_chunks(data):
    chunks, _tail = _split_rw_chunks(data)
    yield from chunks


def _rw_chunk_bytes(container_payload, chunk):
    return container_payload[chunk["start"]:chunk["end"]]


def _rw_library_version(library_id_stamp):
    if library_id_stamp & 0xFFFF0000:
        return (((library_id_stamp >> 14) & 0x3FF00) + 0x30000) | ((library_id_stamp >> 16) & 0x3F)
    return library_id_stamp << 8


def _normalize_material_name(value):
    name = Path(str(value or "")).name.strip().lower()
    while True:
        suffix = Path(name).suffix.lower()
        if suffix in (".png", ".bmp", ".dds", ".tga", ".jpg", ".jpeg", ".txd"):
            name = Path(name).stem
            continue
        if suffix.startswith(".") and suffix[1:].isdigit():
            name = Path(name).stem
            continue
        return name


def _parse_material_name_list(value):
    separators = str(value or "").replace("\r", "\n").replace(";", "\n").replace(",", "\n")
    return {_normalize_material_name(part) for part in separators.split("\n") if _normalize_material_name(part)}


def _material_glow_names(material):
    material_names = set()
    if material is None:
        return material_names

    if getattr(material, "use_nodes", False) and getattr(material, "node_tree", None) is not None:
        for node in material.node_tree.nodes:
            if getattr(node, "type", "") != "TEX_IMAGE":
                continue
            image = getattr(node, "image", None)
            if image is None:
                continue
            material_names.add(_normalize_material_name(getattr(image, "name", "")))
            filepath = getattr(image, "filepath", "")
            if filepath:
                material_names.add(_normalize_material_name(filepath))

    material_names.add(_normalize_material_name(material.name))
    material_names.discard("")
    return material_names


def _object_glow_material_names(obj):
    material_names = set()
    for slot in getattr(obj, "material_slots", ()):
        material_names.update(_material_glow_names(getattr(slot, "material", None)))
    material_names.discard("")
    return material_names


def _object_glow_material_names_string(obj):
    return ", ".join(sorted(_object_glow_material_names(obj)))


def _ensure_mesh_color_attribute(mesh, name):
    color_attributes = getattr(mesh, "color_attributes", None)
    if color_attributes is None:
        raise ValueError("This Blender build does not support color attributes")

    attribute = color_attributes.get(name)
    if attribute is None:
        attribute = color_attributes.new(name=name, type="BYTE_COLOR", domain="CORNER")

    if attribute.domain != "CORNER":
        raise ValueError(f"Color attribute '{name}' must use the CORNER domain")
    return attribute


def _fill_mesh_color_attribute(attribute, rgba):
    color = list(rgba)[:4]
    while len(color) < 4:
        color.append(1.0)

    for item in attribute.data:
        item.color = color


def _find_first_node_by_type(node_tree, node_type):
    for node in node_tree.nodes:
        if getattr(node, "type", "") == node_type:
            return node
    return None


def _apply_glow_preview_to_material(material, glow_color):
    if material is None or not getattr(material, "use_nodes", False) or getattr(material, "node_tree", None) is None:
        return False

    principled = _find_first_node_by_type(material.node_tree, "BSDF_PRINCIPLED")
    if principled is None:
        return False

    emission_socket = principled.inputs.get("Emission Color")
    if emission_socket is None:
        emission_socket = principled.inputs.get("Emission")
    strength_socket = principled.inputs.get("Emission Strength")

    if emission_socket is not None:
        emission_socket.default_value = tuple(list(glow_color)[:3] + [1.0])
    if strength_socket is not None:
        strength_socket.default_value = max(1.0, getattr(strength_socket, "default_value", 1.0))
    return emission_socket is not None


def _apply_glow_setup_to_object(obj):
    if obj.type != "MESH":
        raise ValueError("Glow setup works only on mesh objects")

    mesh = obj.data
    props = obj.defacto_2dfx
    material_names = _object_glow_material_names(obj)
    if material_names:
        props.glow_material_names = ", ".join(sorted(material_names))

    props.glow_enabled = True

    day_color = tuple(list(props.glow_color)[:3] + [1.0]) if props.glow_apply_day else (1.0, 1.0, 1.0, 1.0)
    night_color = tuple(list(props.glow_color)[:3] + [1.0])

    day_attribute = _ensure_mesh_color_attribute(mesh, "Day")
    night_attribute = _ensure_mesh_color_attribute(mesh, "Night")
    _fill_mesh_color_attribute(day_attribute, day_color)
    _fill_mesh_color_attribute(night_attribute, night_color)

    preview_updated = 0
    for slot in obj.material_slots:
        if _apply_glow_preview_to_material(getattr(slot, "material", None), props.glow_color):
            preview_updated += 1

    return {
        "material_names": material_names,
        "preview_updated": preview_updated,
    }


def _float_color_to_rgba(color):
    values = list(color)[:3]
    while len(values) < 3:
        values.append(1.0)
    rgba = [max(0, min(255, int(round(component * 255.0)))) for component in values]
    rgba.append(255)
    return bytes(rgba)


def _decode_rw_string(payload):
    text = payload.split(b"\x00", 1)[0]
    return _normalize_material_name(text.decode("ascii", errors="ignore"))


def _replace_extension_chunk(extension_payload, version, chunk_id, chunk_payload):
    rebuilt = bytearray()
    replaced_existing = False

    children, tail = _split_rw_chunks(extension_payload)
    for child in children:
        if child["id"] == chunk_id:
            replaced_existing = True
            continue
        rebuilt.extend(_rw_chunk_bytes(extension_payload, child))

    rebuilt.extend(_pack_rw_chunk(chunk_id, version, chunk_payload))
    rebuilt.extend(tail)
    return bytes(rebuilt), replaced_existing


def _extract_extension_chunk_payload(extension_payload, chunk_id):
    children, _tail = _split_rw_chunks(extension_payload)
    for child in children:
        if child["id"] == chunk_id:
            return child["payload"]
    return b""


def _geometry_texcoord_set_count(format_flags):
    texcoord_sets = (format_flags >> 16) & 0xFF
    if texcoord_sets != 0:
        return texcoord_sets
    if format_flags & RP_GEOMETRY_TEXTURED2:
        return 2
    if format_flags & RP_GEOMETRY_TEXTURED:
        return 1
    return 0


def _material_texture_name(material_payload):
    children, _tail = _split_rw_chunks(material_payload)
    for child in children:
        if child["id"] != RW_ID_TEXTURE:
            continue
        texture_children, _texture_tail = _split_rw_chunks(child["payload"])
        for texture_child in texture_children:
            if texture_child["id"] == RW_ID_STRING:
                return _decode_rw_string(texture_child["payload"])
    return ""


def _material_names_from_list(material_list_payload):
    children, _tail = _split_rw_chunks(material_list_payload)
    struct_child = next((child for child in children if child["id"] == RW_ID_STRUCT), None)
    if struct_child is None or len(struct_child["payload"]) < 4:
        raise ValueError("Material List section is missing its Struct payload")

    material_count = struct.unpack_from("<I", struct_child["payload"], 0)[0]
    expected_size = 4 + (material_count * 4)
    if len(struct_child["payload"]) < expected_size:
        raise ValueError("Material List Struct is truncated")

    material_indices = struct.unpack_from(f"<{material_count}i", struct_child["payload"], 4)
    material_chunks = [child for child in children if child["id"] == RW_ID_MATERIAL]
    material_iter = iter(material_chunks)
    material_names = []

    for material_index in material_indices:
        if material_index == -1:
            try:
                material_chunk = next(material_iter)
            except StopIteration as exc:
                raise ValueError("Material List does not contain enough Material chunks") from exc
            material_names.append(_material_texture_name(material_chunk["payload"]))
            continue

        if material_index < 0 or material_index >= len(material_names):
            raise ValueError("Material List references an invalid base material")
        material_names.append(material_names[material_index])

    return material_names


def _parse_geometry_struct(struct_payload, version):
    if len(struct_payload) < 16:
        raise ValueError("Geometry Struct is truncated")

    format_flags, num_triangles, num_vertices, num_morph_targets = struct.unpack_from("<IIII", struct_payload, 0)
    offset = 16
    surface_properties = b""

    if _rw_library_version(version) < 0x34000:
        if len(struct_payload) < offset + 12:
            raise ValueError("Geometry Struct surface properties are truncated")
        surface_properties = struct_payload[offset:offset + 12]
        offset += 12

    if format_flags & RP_GEOMETRY_NATIVE:
        return {
            "format_flags": format_flags,
            "num_triangles": num_triangles,
            "num_vertices": num_vertices,
            "num_morph_targets": num_morph_targets,
            "surface_properties": surface_properties,
            "is_native": True,
        }

    prelit_colors = b""
    if format_flags & RP_GEOMETRY_PRELIT:
        prelit_size = num_vertices * 4
        if len(struct_payload) < offset + prelit_size:
            raise ValueError("Geometry Struct prelit colors are truncated")
        prelit_colors = struct_payload[offset:offset + prelit_size]
        offset += prelit_size

    texcoord_size = num_vertices * 8 * _geometry_texcoord_set_count(format_flags)
    if len(struct_payload) < offset + texcoord_size:
        raise ValueError("Geometry Struct texture coordinates are truncated")
    texcoords = struct_payload[offset:offset + texcoord_size]
    offset += texcoord_size

    triangle_size = num_triangles * 8
    if len(struct_payload) < offset + triangle_size:
        raise ValueError("Geometry Struct triangle data is truncated")
    triangles = struct_payload[offset:offset + triangle_size]
    offset += triangle_size

    morph_targets = []
    for _index in range(num_morph_targets):
        if len(struct_payload) < offset + 24:
            raise ValueError("Geometry Struct morph target header is truncated")

        sphere = struct_payload[offset:offset + 16]
        offset += 16
        has_vertices, has_normals = struct.unpack_from("<II", struct_payload, offset)
        offset += 8

        vertex_bytes = b""
        if has_vertices:
            vertex_size = num_vertices * 12
            if len(struct_payload) < offset + vertex_size:
                raise ValueError("Geometry Struct morph vertices are truncated")
            vertex_bytes = struct_payload[offset:offset + vertex_size]
            offset += vertex_size

        normal_bytes = b""
        if has_normals:
            normal_size = num_vertices * 12
            if len(struct_payload) < offset + normal_size:
                raise ValueError("Geometry Struct morph normals are truncated")
            normal_bytes = struct_payload[offset:offset + normal_size]
            offset += normal_size

        morph_targets.append(
            {
                "sphere": sphere,
                "has_vertices": has_vertices,
                "has_normals": has_normals,
                "vertices": vertex_bytes,
                "normals": normal_bytes,
            }
        )

    return {
        "format_flags": format_flags,
        "num_triangles": num_triangles,
        "num_vertices": num_vertices,
        "num_morph_targets": num_morph_targets,
        "surface_properties": surface_properties,
        "prelit_colors": prelit_colors,
        "texcoords": texcoords,
        "triangles": triangles,
        "morph_targets": morph_targets,
        "tail": struct_payload[offset:],
        "is_native": False,
    }


def _build_geometry_struct(layout, day_colors, disable_normals):
    format_flags = layout["format_flags"] | RP_GEOMETRY_PRELIT
    if disable_normals:
        format_flags &= ~RP_GEOMETRY_NORMALS
        format_flags &= ~RP_GEOMETRY_LIGHT

    parts = [
        struct.pack(
            "<IIII",
            format_flags,
            layout["num_triangles"],
            layout["num_vertices"],
            layout["num_morph_targets"],
        )
    ]

    if layout["surface_properties"]:
        parts.append(layout["surface_properties"])

    parts.append(day_colors)
    parts.append(layout["texcoords"])
    parts.append(layout["triangles"])

    for morph_target in layout["morph_targets"]:
        parts.append(morph_target["sphere"])
        has_normals = 0 if disable_normals else morph_target["has_normals"]
        parts.append(struct.pack("<II", morph_target["has_vertices"], has_normals))
        if morph_target["has_vertices"]:
            parts.append(morph_target["vertices"])
        if not disable_normals and morph_target["has_normals"]:
            parts.append(morph_target["normals"])

    parts.append(layout["tail"])
    return b"".join(parts)


def _vertices_for_glow_materials(triangle_bytes, material_names, glow_materials):
    vertices = set()
    matched_materials = set()

    for offset in range(0, len(triangle_bytes), 8):
        vertex2, vertex1, material_index, vertex3 = struct.unpack_from("<HHHH", triangle_bytes, offset)
        if material_index >= len(material_names):
            continue

        material_name = material_names[material_index]
        if material_name not in glow_materials:
            continue

        matched_materials.add(material_name)
        vertices.update((vertex1, vertex2, vertex3))

    return vertices, matched_materials


def _extra_vert_colors_from_extension(extension_payload, num_vertices):
    if not extension_payload:
        return None

    payload = _extract_extension_chunk_payload(extension_payload, RW_ID_EXTRA_VERT_COLOUR)
    if len(payload) < 4:
        return None

    if struct.unpack_from("<I", payload, 0)[0] == 0:
        return None

    color_size = num_vertices * 4
    if len(payload) < 4 + color_size:
        return None

    return bytearray(payload[4:4 + color_size])


def _collect_glow_specs(context, use_selection_only):
    source = context.selected_objects if use_selection_only else context.scene.objects
    glow_specs = []
    skipped_objects = []

    for obj in source:
        props = getattr(obj, "defacto_2dfx", None)
        if obj.type != "MESH" or props is None or not props.glow_enabled:
            continue

        material_names = _parse_material_name_list(props.glow_material_names)
        if not material_names:
            material_names = _object_glow_material_names(obj)
        if not material_names:
            skipped_objects.append(obj.name)
            continue

        glow_specs.append(
            {
                "label": obj.name,
                "material_names": material_names,
                "glow_color": props.glow_color,
                "apply_day": props.glow_apply_day,
                "disable_normals": props.glow_disable_normals,
            }
        )

    return glow_specs, skipped_objects


def _patch_geometry_glow_materials(geometry_payload, geometry_version, glow_materials, glow_rgba, apply_day, disable_normals):
    children, tail = _split_rw_chunks(geometry_payload)
    struct_child = next((child for child in children if child["id"] == RW_ID_STRUCT), None)
    material_list_child = next((child for child in children if child["id"] == RW_ID_MATERIAL_LIST), None)
    extension_child = next((child for child in children if child["id"] == RW_ID_EXTENSION), None)

    if struct_child is None or material_list_child is None:
        return geometry_payload, None

    layout = _parse_geometry_struct(struct_child["payload"], struct_child["version"])
    if layout["is_native"]:
        return geometry_payload, {"native_geometry": True}

    material_names = _material_names_from_list(material_list_child["payload"])
    matched_vertices, matched_materials = _vertices_for_glow_materials(
        layout["triangles"],
        material_names,
        glow_materials,
    )
    if not matched_vertices:
        return geometry_payload, None

    vertex_count = layout["num_vertices"]
    day_colors = bytearray(layout["prelit_colors"]) if layout["prelit_colors"] else bytearray(b"\xFF\xFF\xFF\xFF" * vertex_count)
    extension_payload = extension_child["payload"] if extension_child is not None else b""
    night_colors = _extra_vert_colors_from_extension(extension_payload, vertex_count)
    if night_colors is None:
        night_colors = bytearray(day_colors)

    for vertex_index in matched_vertices:
        color_offset = vertex_index * 4
        night_colors[color_offset:color_offset + 4] = glow_rgba
        if apply_day:
            day_colors[color_offset:color_offset + 4] = glow_rgba

    new_struct_payload = _build_geometry_struct(layout, bytes(day_colors), disable_normals)
    extension_version = extension_child["version"] if extension_child is not None else geometry_version
    new_extension_payload, replaced_existing = _replace_extension_chunk(
        extension_payload,
        extension_version,
        RW_ID_EXTRA_VERT_COLOUR,
        struct.pack("<I", 1) + bytes(night_colors),
    )

    rebuilt = bytearray()
    extension_found = False
    for child in children:
        if child["id"] == RW_ID_STRUCT:
            rebuilt.extend(_pack_rw_chunk(RW_ID_STRUCT, child["version"], new_struct_payload))
            continue

        if child["id"] == RW_ID_EXTENSION and not extension_found:
            extension_found = True
            rebuilt.extend(_pack_rw_chunk(RW_ID_EXTENSION, child["version"], new_extension_payload))
            continue

        rebuilt.extend(_rw_chunk_bytes(geometry_payload, child))

    if not extension_found:
        rebuilt.extend(_pack_rw_chunk(RW_ID_EXTENSION, extension_version, new_extension_payload))

    rebuilt.extend(tail)
    return (
        bytes(rebuilt),
        {
            "native_geometry": False,
            "matched_materials": matched_materials,
            "vertex_count": len(matched_vertices),
            "replaced_existing": replaced_existing,
        },
    )


def _patch_geometry_list_glow_materials(geometry_list_payload, glow_materials, glow_rgba, apply_day, disable_normals):
    children, tail = _split_rw_chunks(geometry_list_payload)
    rebuilt = bytearray()
    patched_geometries = set()
    matched_materials = set()
    vertex_count = 0
    native_geometry_count = 0
    replaced_existing = False
    geometry_index = -1

    for child in children:
        if child["id"] != RW_ID_GEOMETRY:
            rebuilt.extend(_rw_chunk_bytes(geometry_list_payload, child))
            continue

        geometry_index += 1
        new_geometry_payload, patch_info = _patch_geometry_glow_materials(
            child["payload"],
            child["version"],
            glow_materials,
            glow_rgba,
            apply_day,
            disable_normals,
        )

        if patch_info is None:
            rebuilt.extend(_rw_chunk_bytes(geometry_list_payload, child))
            continue

        if patch_info["native_geometry"]:
            native_geometry_count += 1
            rebuilt.extend(_rw_chunk_bytes(geometry_list_payload, child))
            continue

        patched_geometries.add(geometry_index)
        matched_materials.update(patch_info["matched_materials"])
        vertex_count += patch_info["vertex_count"]
        replaced_existing = replaced_existing or patch_info["replaced_existing"]
        rebuilt.extend(_pack_rw_chunk(RW_ID_GEOMETRY, child["version"], new_geometry_payload))

    rebuilt.extend(tail)
    return bytes(rebuilt), {
        "geometry_indexes": patched_geometries,
        "matched_materials": matched_materials,
        "vertex_count": vertex_count,
        "native_geometry_count": native_geometry_count,
        "replaced_existing": replaced_existing,
    }


def _atomic_geometry_index(atomic_payload):
    children, _tail = _split_rw_chunks(atomic_payload)
    struct_child = next((child for child in children if child["id"] == RW_ID_STRUCT), None)
    if struct_child is None or len(struct_child["payload"]) < 12:
        raise ValueError("Atomic section is missing its Struct payload")
    return struct.unpack_from("<III", struct_child["payload"], 0)[1]


def _patch_atomic_pipeline(atomic_payload, atomic_version):
    children, tail = _split_rw_chunks(atomic_payload)
    extension_child = next((child for child in children if child["id"] == RW_ID_EXTENSION), None)
    extension_payload = extension_child["payload"] if extension_child is not None else b""
    extension_version = extension_child["version"] if extension_child is not None else atomic_version
    new_extension_payload, replaced_existing = _replace_extension_chunk(
        extension_payload,
        extension_version,
        RW_ID_PIPELINE_SET,
        struct.pack("<I", RW_PIPELINE_NIGHT_VERTEX_COLOURS),
    )

    rebuilt = bytearray()
    extension_found = False
    for child in children:
        if child["id"] == RW_ID_EXTENSION and not extension_found:
            extension_found = True
            rebuilt.extend(_pack_rw_chunk(RW_ID_EXTENSION, child["version"], new_extension_payload))
            continue
        rebuilt.extend(_rw_chunk_bytes(atomic_payload, child))

    if not extension_found:
        rebuilt.extend(_pack_rw_chunk(RW_ID_EXTENSION, extension_version, new_extension_payload))

    rebuilt.extend(tail)
    return bytes(rebuilt), replaced_existing


def _patch_clump_glow_materials(clump_payload, glow_materials, glow_rgba, apply_day, disable_normals):
    children, tail = _split_rw_chunks(clump_payload)
    geometry_list_child = next((child for child in children if child["id"] == RW_ID_GEOMETRY_LIST), None)
    if geometry_list_child is None:
        raise ValueError("No Geometry List section found inside the DFF model")

    new_geometry_list_payload, glow_info = _patch_geometry_list_glow_materials(
        geometry_list_child["payload"],
        glow_materials,
        glow_rgba,
        apply_day,
        disable_normals,
    )
    if not glow_info["geometry_indexes"]:
        return clump_payload, None

    rebuilt = bytearray()
    replaced_pipeline = False
    patched_atomic_count = 0
    for child in children:
        if child is geometry_list_child:
            rebuilt.extend(_pack_rw_chunk(RW_ID_GEOMETRY_LIST, child["version"], new_geometry_list_payload))
            continue

        if child["id"] != RW_ID_ATOMIC:
            rebuilt.extend(_rw_chunk_bytes(clump_payload, child))
            continue

        geometry_index = _atomic_geometry_index(child["payload"])
        if geometry_index not in glow_info["geometry_indexes"]:
            rebuilt.extend(_rw_chunk_bytes(clump_payload, child))
            continue

        new_atomic_payload, atomic_replaced_existing = _patch_atomic_pipeline(child["payload"], child["version"])
        patched_atomic_count += 1
        replaced_pipeline = replaced_pipeline or atomic_replaced_existing
        rebuilt.extend(_pack_rw_chunk(RW_ID_ATOMIC, child["version"], new_atomic_payload))

    rebuilt.extend(tail)
    glow_info["patched_atomic_count"] = patched_atomic_count
    glow_info["replaced_pipeline"] = replaced_pipeline
    return bytes(rebuilt), glow_info


def _geometry_has_2dfx(geometry_payload):
    children, _tail = _split_rw_chunks(geometry_payload)
    for child in children:
        if child["id"] != RW_ID_EXTENSION:
            continue
        extension_children, _extension_tail = _split_rw_chunks(child["payload"])
        for extension_child in extension_children:
            if extension_child["id"] == RW_ID_2DFX:
                return True
    return False


def _replace_extension_2dfx(extension_payload, version, sae_bytes):
    rebuilt = bytearray()
    replaced_existing = False

    children, tail = _split_rw_chunks(extension_payload)
    for child in children:
        if child["id"] == RW_ID_2DFX:
            replaced_existing = True
            continue
        rebuilt.extend(_rw_chunk_bytes(extension_payload, child))

    rebuilt.extend(_pack_rw_chunk(RW_ID_2DFX, version, sae_bytes))
    rebuilt.extend(tail)
    return bytes(rebuilt), replaced_existing


def _remove_extension_chunk(extension_payload, chunk_id):
    rebuilt = bytearray()
    removed = False
    children, tail = _split_rw_chunks(extension_payload)
    for child in children:
        if child["id"] == chunk_id:
            removed = True
            continue
        rebuilt.extend(_rw_chunk_bytes(extension_payload, child))
    rebuilt.extend(tail)
    return bytes(rebuilt), removed


def _replace_extension_aels(extension_payload, version, aels_bytes):
    return _replace_extension_chunk(extension_payload, version, RW_ID_AELS, aels_bytes)


def _replace_geometry_2dfx(geometry_payload, version, sae_bytes, aels_bytes=None, strip_aels=False):
    rebuilt = bytearray()
    extension_found = False
    replaced_existing = False
    replaced_aels = False

    children, tail = _split_rw_chunks(geometry_payload)
    for child in children:
        if child["id"] == RW_ID_EXTENSION and not extension_found:
            extension_found = True
            new_extension_payload, replaced_existing = _replace_extension_2dfx(
                child["payload"],
                child["version"],
                sae_bytes,
            )
            if aels_bytes is not None:
                new_extension_payload, replaced_aels = _replace_extension_aels(
                    new_extension_payload,
                    child["version"],
                    aels_bytes,
                )
            elif strip_aels:
                new_extension_payload, replaced_aels = _remove_extension_chunk(new_extension_payload, RW_ID_AELS)
            rebuilt.extend(_pack_rw_chunk(RW_ID_EXTENSION, child["version"], new_extension_payload))
            continue

        rebuilt.extend(_rw_chunk_bytes(geometry_payload, child))

    if not extension_found:
        extension_payload = _pack_rw_chunk(RW_ID_2DFX, version, sae_bytes)
        if aels_bytes is not None:
            extension_payload += _pack_rw_chunk(RW_ID_AELS, version, aels_bytes)
        rebuilt.extend(_pack_rw_chunk(RW_ID_EXTENSION, version, extension_payload))

    rebuilt.extend(tail)
    return bytes(rebuilt), replaced_existing, replaced_aels


def _replace_geometry_list_2dfx(geometry_list_payload, version, sae_bytes, aels_bytes=None, strip_aels=False):
    children, tail = _split_rw_chunks(geometry_list_payload)
    geometry_positions = [index for index, child in enumerate(children) if child["id"] == RW_ID_GEOMETRY]
    if not geometry_positions:
        raise ValueError("No Geometry sections found inside the DFF model")

    target_index = None
    for index in geometry_positions:
        if _geometry_has_2dfx(children[index]["payload"]):
            target_index = index
            break
    if target_index is None:
        target_index = geometry_positions[0]

    rebuilt = bytearray()
    replaced_existing = False
    replaced_aels = False
    geometry_number = 0
    target_geometry_number = 1

    for index, child in enumerate(children):
        if child["id"] == RW_ID_GEOMETRY:
            geometry_number += 1
        if index == target_index:
            new_geometry_payload, replaced_existing, replaced_aels = _replace_geometry_2dfx(
                child["payload"],
                child["version"],
                sae_bytes,
                aels_bytes=aels_bytes,
                strip_aels=strip_aels,
            )
            rebuilt.extend(_pack_rw_chunk(RW_ID_GEOMETRY, child["version"], new_geometry_payload))
            target_geometry_number = geometry_number
            continue

        rebuilt.extend(_rw_chunk_bytes(geometry_list_payload, child))

    rebuilt.extend(tail)
    return bytes(rebuilt), target_geometry_number, replaced_existing, replaced_aels


def _replace_clump_2dfx(clump_payload, version, sae_bytes, aels_bytes=None, strip_aels=False):
    rebuilt = bytearray()
    patched_geometry_list = False
    target_geometry_number = 1
    replaced_existing = False
    replaced_aels = False

    children, tail = _split_rw_chunks(clump_payload)
    for child in children:
        if child["id"] == RW_ID_GEOMETRY_LIST and not patched_geometry_list:
            patched_geometry_list = True
            new_geometry_list_payload, target_geometry_number, replaced_existing, replaced_aels = _replace_geometry_list_2dfx(
                child["payload"],
                child["version"],
                sae_bytes,
                aels_bytes=aels_bytes,
                strip_aels=strip_aels,
            )
            rebuilt.extend(_pack_rw_chunk(RW_ID_GEOMETRY_LIST, child["version"], new_geometry_list_payload))
            continue

        rebuilt.extend(_rw_chunk_bytes(clump_payload, child))

    if not patched_geometry_list:
        raise ValueError("No Geometry List section found inside the DFF model")

    rebuilt.extend(tail)
    return bytes(rebuilt), target_geometry_number, replaced_existing, replaced_aels


def _patch_material_aels_light_color(material_payload):
    texture_name = _material_texture_name(material_payload)
    if _normalize_material_name(texture_name) != _normalize_material_name(AELS_LIGHT_TEXTURE_NAME):
        return material_payload, False

    children, tail = _split_rw_chunks(material_payload)
    rebuilt = bytearray()
    patched = False
    target_rgba = bytes((
        int(round(AELS_LIGHT_MATERIAL_COLOR[0] * 255.0)),
        int(round(AELS_LIGHT_MATERIAL_COLOR[1] * 255.0)),
        int(round(AELS_LIGHT_MATERIAL_COLOR[2] * 255.0)),
        AELS_LIGHT_MATERIAL_DFF_ALPHA,
    ))

    for child in children:
        if child["id"] == RW_ID_STRUCT and not patched and len(child["payload"]) >= 8:
            new_payload = bytearray(child["payload"])
            new_payload[4:8] = target_rgba
            rebuilt.extend(_pack_rw_chunk(RW_ID_STRUCT, child["version"], bytes(new_payload)))
            patched = True
            continue
        rebuilt.extend(_rw_chunk_bytes(material_payload, child))

    rebuilt.extend(tail)
    return bytes(rebuilt), patched


def _patch_material_list_aels_light_colors(material_list_payload):
    children, tail = _split_rw_chunks(material_list_payload)
    rebuilt = bytearray()
    patched_count = 0

    for child in children:
        if child["id"] == RW_ID_MATERIAL:
            new_payload, patched = _patch_material_aels_light_color(child["payload"])
            if patched:
                patched_count += 1
                rebuilt.extend(_pack_rw_chunk(RW_ID_MATERIAL, child["version"], new_payload))
                continue
        rebuilt.extend(_rw_chunk_bytes(material_list_payload, child))

    rebuilt.extend(tail)
    return bytes(rebuilt), patched_count


def _patch_geometry_aels_light_material_colors(geometry_payload):
    children, tail = _split_rw_chunks(geometry_payload)
    rebuilt = bytearray()
    patched_count = 0

    for child in children:
        if child["id"] == RW_ID_MATERIAL_LIST:
            new_payload, child_patched_count = _patch_material_list_aels_light_colors(child["payload"])
            patched_count += child_patched_count
            rebuilt.extend(_pack_rw_chunk(RW_ID_MATERIAL_LIST, child["version"], new_payload))
            continue
        rebuilt.extend(_rw_chunk_bytes(geometry_payload, child))

    rebuilt.extend(tail)
    return bytes(rebuilt), patched_count


def _patch_geometry_list_aels_light_material_colors(geometry_list_payload):
    children, tail = _split_rw_chunks(geometry_list_payload)
    rebuilt = bytearray()
    patched_count = 0

    for child in children:
        if child["id"] == RW_ID_GEOMETRY:
            new_payload, child_patched_count = _patch_geometry_aels_light_material_colors(child["payload"])
            patched_count += child_patched_count
            rebuilt.extend(_pack_rw_chunk(RW_ID_GEOMETRY, child["version"], new_payload))
            continue
        rebuilt.extend(_rw_chunk_bytes(geometry_list_payload, child))

    rebuilt.extend(tail)
    return bytes(rebuilt), patched_count


def _patch_clump_aels_light_material_colors(clump_payload):
    children, tail = _split_rw_chunks(clump_payload)
    rebuilt = bytearray()
    patched_count = 0

    for child in children:
        if child["id"] == RW_ID_GEOMETRY_LIST:
            new_payload, child_patched_count = _patch_geometry_list_aels_light_material_colors(child["payload"])
            patched_count += child_patched_count
            rebuilt.extend(_pack_rw_chunk(RW_ID_GEOMETRY_LIST, child["version"], new_payload))
            continue
        rebuilt.extend(_rw_chunk_bytes(clump_payload, child))

    rebuilt.extend(tail)
    return bytes(rebuilt), patched_count


def _patch_dff_aels_light_material_colors(dff_bytes):
    chunks, tail = _split_rw_chunks(dff_bytes)
    rebuilt = bytearray()
    patched_count = 0

    for chunk in chunks:
        if chunk["id"] == RW_ID_CLUMP:
            new_payload, child_patched_count = _patch_clump_aels_light_material_colors(chunk["payload"])
            patched_count += child_patched_count
            rebuilt.extend(_pack_rw_chunk(RW_ID_CLUMP, chunk["version"], new_payload))
            continue
        rebuilt.extend(_rw_chunk_bytes(dff_bytes, chunk))

    rebuilt.extend(tail)
    return bytes(rebuilt), patched_count


def _geometry_aels_light_material_state(geometry_payload):
    target_name = _normalize_material_name(AELS_LIGHT_TEXTURE_NAME)
    children, _tail = _split_rw_chunks(geometry_payload)
    material_list_child = next((child for child in children if child["id"] == RW_ID_MATERIAL_LIST), None)
    if material_list_child is None:
        return False, False

    material_names = [_normalize_material_name(name) for name in _material_names_from_list(material_list_child["payload"])]
    material_names = [name for name in material_names if name]
    has_aels_light = target_name in material_names
    only_aels_light = has_aels_light and all(name == target_name for name in material_names)
    return has_aels_light, only_aels_light


def _build_geometry_struct_without_prelit(layout):
    format_flags = layout["format_flags"] & ~RP_GEOMETRY_PRELIT
    parts = [
        struct.pack(
            "<IIII",
            format_flags,
            layout["num_triangles"],
            layout["num_vertices"],
            layout["num_morph_targets"],
        )
    ]

    if layout["surface_properties"]:
        parts.append(layout["surface_properties"])

    parts.append(layout["texcoords"])
    parts.append(layout["triangles"])

    for morph_target in layout["morph_targets"]:
        parts.append(morph_target["sphere"])
        parts.append(struct.pack("<II", morph_target["has_vertices"], morph_target["has_normals"]))
        if morph_target["has_vertices"]:
            parts.append(morph_target["vertices"])
        if morph_target["has_normals"]:
            parts.append(morph_target["normals"])

    parts.append(layout["tail"])
    return b"".join(parts)


def _strip_geometry_aels_light_static_glow(geometry_payload, geometry_version):
    has_aels_light, only_aels_light = _geometry_aels_light_material_state(geometry_payload)
    if not has_aels_light:
        return geometry_payload, {
            "has_aels_light": False,
            "changed": False,
            "removed_extra_vert": False,
            "removed_prelit": False,
        }

    children, tail = _split_rw_chunks(geometry_payload)
    struct_child = next((child for child in children if child["id"] == RW_ID_STRUCT), None)
    extension_child = next((child for child in children if child["id"] == RW_ID_EXTENSION), None)

    new_struct_payload = None
    removed_prelit = False
    if only_aels_light and struct_child is not None:
        layout = _parse_geometry_struct(struct_child["payload"], geometry_version)
        if (
            not layout.get("is_native") and
            (layout["format_flags"] & RP_GEOMETRY_PRELIT) and
            (layout["format_flags"] & RP_GEOMETRY_NORMALS) and
            (layout["format_flags"] & RP_GEOMETRY_LIGHT)
        ):
            new_struct_payload = _build_geometry_struct_without_prelit(layout)
            removed_prelit = True

    new_extension_payload = None
    removed_extra_vert = False
    if extension_child is not None:
        new_extension_payload, removed_extra_vert = _remove_extension_chunk(
            extension_child["payload"],
            RW_ID_EXTRA_VERT_COLOUR,
        )

    if not removed_prelit and not removed_extra_vert:
        return geometry_payload, {
            "has_aels_light": True,
            "changed": False,
            "removed_extra_vert": False,
            "removed_prelit": False,
        }

    rebuilt = bytearray()
    struct_replaced = False
    extension_replaced = False
    for child in children:
        if child["id"] == RW_ID_STRUCT and not struct_replaced and new_struct_payload is not None:
            struct_replaced = True
            rebuilt.extend(_pack_rw_chunk(RW_ID_STRUCT, child["version"], new_struct_payload))
            continue

        if child["id"] == RW_ID_EXTENSION and not extension_replaced and new_extension_payload is not None:
            extension_replaced = True
            rebuilt.extend(_pack_rw_chunk(RW_ID_EXTENSION, child["version"], new_extension_payload))
            continue

        rebuilt.extend(_rw_chunk_bytes(geometry_payload, child))

    rebuilt.extend(tail)
    return bytes(rebuilt), {
        "has_aels_light": True,
        "changed": True,
        "removed_extra_vert": removed_extra_vert,
        "removed_prelit": removed_prelit,
    }


def _strip_geometry_list_aels_light_static_glow(geometry_list_payload):
    children, tail = _split_rw_chunks(geometry_list_payload)
    rebuilt = bytearray()
    geometry_index = -1
    aels_geometry_indexes = set()
    removed_extra_vert_count = 0
    removed_prelit_count = 0

    for child in children:
        if child["id"] != RW_ID_GEOMETRY:
            rebuilt.extend(_rw_chunk_bytes(geometry_list_payload, child))
            continue

        geometry_index += 1
        new_payload, strip_info = _strip_geometry_aels_light_static_glow(child["payload"], child["version"])
        if strip_info["has_aels_light"]:
            aels_geometry_indexes.add(geometry_index)
        if strip_info["removed_extra_vert"]:
            removed_extra_vert_count += 1
        if strip_info["removed_prelit"]:
            removed_prelit_count += 1

        if strip_info["changed"]:
            rebuilt.extend(_pack_rw_chunk(RW_ID_GEOMETRY, child["version"], new_payload))
        else:
            rebuilt.extend(_rw_chunk_bytes(geometry_list_payload, child))

    rebuilt.extend(tail)
    return bytes(rebuilt), {
        "geometry_indexes": aels_geometry_indexes,
        "removed_extra_vert_count": removed_extra_vert_count,
        "removed_prelit_count": removed_prelit_count,
    }


def _strip_atomic_aels_light_night_pipeline(atomic_payload):
    children, tail = _split_rw_chunks(atomic_payload)
    extension_child = next((child for child in children if child["id"] == RW_ID_EXTENSION), None)
    if extension_child is None:
        return atomic_payload, False

    extension_children, extension_tail = _split_rw_chunks(extension_child["payload"])
    new_extension_payload = bytearray()
    removed_pipeline = False
    for extension_part in extension_children:
        is_aels_night_pipeline = (
            extension_part["id"] == RW_ID_PIPELINE_SET and
            len(extension_part["payload"]) >= 4 and
            struct.unpack_from("<I", extension_part["payload"], 0)[0] == RW_PIPELINE_NIGHT_VERTEX_COLOURS
        )
        if is_aels_night_pipeline:
            removed_pipeline = True
            continue
        new_extension_payload.extend(_rw_chunk_bytes(extension_child["payload"], extension_part))

    if not removed_pipeline:
        return atomic_payload, False

    new_extension_payload.extend(extension_tail)
    rebuilt = bytearray()
    extension_replaced = False
    for child in children:
        if child["id"] == RW_ID_EXTENSION and not extension_replaced:
            extension_replaced = True
            rebuilt.extend(_pack_rw_chunk(RW_ID_EXTENSION, child["version"], bytes(new_extension_payload)))
            continue
        rebuilt.extend(_rw_chunk_bytes(atomic_payload, child))

    rebuilt.extend(tail)
    return bytes(rebuilt), True


def _strip_clump_aels_light_static_glow(clump_payload):
    children, tail = _split_rw_chunks(clump_payload)
    geometry_list_child = next((child for child in children if child["id"] == RW_ID_GEOMETRY_LIST), None)
    if geometry_list_child is None:
        return clump_payload, {
            "removed_extra_vert_count": 0,
            "removed_prelit_count": 0,
            "removed_pipeline_count": 0,
        }

    new_geometry_list_payload, geometry_info = _strip_geometry_list_aels_light_static_glow(geometry_list_child["payload"])
    aels_geometry_indexes = geometry_info["geometry_indexes"]
    removed_pipeline_count = 0

    rebuilt = bytearray()
    for child in children:
        if child is geometry_list_child:
            rebuilt.extend(_pack_rw_chunk(RW_ID_GEOMETRY_LIST, child["version"], new_geometry_list_payload))
            continue

        if child["id"] == RW_ID_ATOMIC and aels_geometry_indexes:
            geometry_index = _atomic_geometry_index(child["payload"])
            if geometry_index in aels_geometry_indexes:
                new_atomic_payload, removed_pipeline = _strip_atomic_aels_light_night_pipeline(child["payload"])
                if removed_pipeline:
                    removed_pipeline_count += 1
                    rebuilt.extend(_pack_rw_chunk(RW_ID_ATOMIC, child["version"], new_atomic_payload))
                    continue

        rebuilt.extend(_rw_chunk_bytes(clump_payload, child))

    rebuilt.extend(tail)
    return bytes(rebuilt), {
        "removed_extra_vert_count": geometry_info["removed_extra_vert_count"],
        "removed_prelit_count": geometry_info["removed_prelit_count"],
        "removed_pipeline_count": removed_pipeline_count,
    }


def _strip_dff_aels_light_static_glow(dff_bytes):
    chunks, tail = _split_rw_chunks(dff_bytes)
    rebuilt = bytearray()
    removed_extra_vert_count = 0
    removed_prelit_count = 0
    removed_pipeline_count = 0

    for chunk in chunks:
        if chunk["id"] == RW_ID_CLUMP:
            new_payload, strip_info = _strip_clump_aels_light_static_glow(chunk["payload"])
            removed_extra_vert_count += strip_info["removed_extra_vert_count"]
            removed_prelit_count += strip_info["removed_prelit_count"]
            removed_pipeline_count += strip_info["removed_pipeline_count"]
            rebuilt.extend(_pack_rw_chunk(RW_ID_CLUMP, chunk["version"], new_payload))
            continue
        rebuilt.extend(_rw_chunk_bytes(dff_bytes, chunk))

    rebuilt.extend(tail)
    return bytes(rebuilt), {
        "removed_extra_vert_count": removed_extra_vert_count,
        "removed_prelit_count": removed_prelit_count,
        "removed_pipeline_count": removed_pipeline_count,
    }


def _make_backup_path(dff_path):
    candidate = dff_path.with_name(f"{dff_path.name}.bak")
    if not candidate.exists():
        return candidate

    index = 1
    while True:
        candidate = dff_path.with_name(f"{dff_path.name}.bak.{index:03d}")
        if not candidate.exists():
            return candidate
        index += 1


def inject_sae_into_dff(filepath, sae_bytes, aels_bytes=None, create_backup=True, strip_aels=False):
    dff_path = Path(bpy.path.abspath(filepath))
    if dff_path.suffix.lower() != ".dff":
        raise ValueError("Select a .dff model file")
    if not dff_path.exists():
        raise ValueError("Selected .dff file does not exist")

    original_bytes = dff_path.read_bytes()
    rebuilt = bytearray()
    patched_clump = False
    target_geometry_number = 1
    replaced_existing = False
    replaced_aels = False

    chunks, tail = _split_rw_chunks(original_bytes)
    for chunk in chunks:
        if chunk["id"] == RW_ID_CLUMP and not patched_clump:
            patched_clump = True
            new_clump_payload, target_geometry_number, replaced_existing, replaced_aels = _replace_clump_2dfx(
                chunk["payload"],
                chunk["version"],
                sae_bytes,
                aels_bytes=aels_bytes,
                strip_aels=strip_aels,
            )
            rebuilt.extend(_pack_rw_chunk(RW_ID_CLUMP, chunk["version"], new_clump_payload))
            continue

        rebuilt.extend(_rw_chunk_bytes(original_bytes, chunk))

    if not patched_clump:
        raise ValueError("No Clump section found inside the DFF model")

    rebuilt.extend(tail)
    rebuilt_bytes, static_glow_info = _strip_dff_aels_light_static_glow(bytes(rebuilt))

    backup_path = None
    if create_backup:
        backup_path = _make_backup_path(dff_path)
        backup_path.write_bytes(original_bytes)

    dff_path.write_bytes(rebuilt_bytes)
    return {
        "backup_path": str(backup_path) if backup_path is not None else "",
        "geometry_index": target_geometry_number,
        "replaced_existing": replaced_existing,
        "aels_embedded": aels_bytes is not None,
        "aels_replaced_existing": replaced_aels,
        "aels_static_glow_extra_removed": static_glow_info["removed_extra_vert_count"],
        "aels_static_glow_prelit_removed": static_glow_info["removed_prelit_count"],
        "aels_static_glow_pipeline_removed": static_glow_info["removed_pipeline_count"],
    }


def _inject_glow_materials_into_bytes(dff_bytes, material_names, glow_color, apply_day=False, disable_normals=True):
    glow_materials = material_names if isinstance(material_names, set) else _parse_material_name_list(material_names)
    if not glow_materials:
        raise ValueError("Enter at least one DFF material texture name")

    rebuilt = bytearray()
    patched_clump = False
    glow_info = None

    chunks, tail = _split_rw_chunks(dff_bytes)
    for chunk in chunks:
        if chunk["id"] == RW_ID_CLUMP and not patched_clump:
            new_clump_payload, glow_info = _patch_clump_glow_materials(
                chunk["payload"],
                glow_materials,
                _float_color_to_rgba(glow_color),
                apply_day,
                disable_normals,
            )
            if glow_info is None:
                rebuilt.extend(_rw_chunk_bytes(dff_bytes, chunk))
                patched_clump = True
                continue

            rebuilt.extend(_pack_rw_chunk(RW_ID_CLUMP, chunk["version"], new_clump_payload))
            patched_clump = True
            continue

        rebuilt.extend(_rw_chunk_bytes(dff_bytes, chunk))

    if not patched_clump:
        raise ValueError("No Clump section found inside the DFF model")

    rebuilt.extend(tail)
    if glow_info is None:
        return None

    return {
        "bytes": bytes(rebuilt),
        "geometry_indexes": set(glow_info["geometry_indexes"]),
        "geometry_count": len(glow_info["geometry_indexes"]),
        "vertex_count": glow_info["vertex_count"],
        "matched_materials": sorted(glow_info["matched_materials"]),
        "native_geometry_count": glow_info["native_geometry_count"],
        "patched_atomic_count": glow_info["patched_atomic_count"],
        "replaced_existing": glow_info["replaced_existing"] or glow_info["replaced_pipeline"],
    }


def inject_glow_specs_into_dff(filepath, glow_specs, create_backup=True):
    dff_path = Path(bpy.path.abspath(filepath))
    if dff_path.suffix.lower() != ".dff":
        raise ValueError("Select a .dff model file")
    if not dff_path.exists():
        raise ValueError("Selected .dff file does not exist")

    if not glow_specs:
        raise ValueError("No tagged glow objects found to apply")

    original_bytes = dff_path.read_bytes()
    current_bytes = original_bytes
    geometry_indexes = set()
    matched_materials = set()
    matched_labels = []
    missing_labels = []
    vertex_count = 0
    native_geometry_count = 0
    patched_atomic_count = 0
    replaced_existing = False

    for spec in glow_specs:
        result = _inject_glow_materials_into_bytes(
            current_bytes,
            spec["material_names"],
            spec["glow_color"],
            apply_day=spec.get("apply_day", False),
            disable_normals=spec.get("disable_normals", True),
        )
        if result is None:
            missing_labels.append(spec["label"])
            continue

        current_bytes = result["bytes"]
        geometry_indexes.update(result["geometry_indexes"])
        matched_materials.update(result["matched_materials"])
        matched_labels.append(spec["label"])
        vertex_count += result["vertex_count"]
        native_geometry_count += result["native_geometry_count"]
        patched_atomic_count += result["patched_atomic_count"]
        replaced_existing = replaced_existing or result["replaced_existing"]

    if not matched_labels:
        raise ValueError("No matching glow materials were found in the DFF geometries")

    backup_path = None
    if create_backup:
        backup_path = _make_backup_path(dff_path)
        backup_path.write_bytes(original_bytes)

    dff_path.write_bytes(current_bytes)
    return {
        "backup_path": str(backup_path) if backup_path is not None else "",
        "geometry_count": len(geometry_indexes),
        "vertex_count": vertex_count,
        "matched_materials": sorted(matched_materials),
        "matched_labels": matched_labels,
        "missing_labels": missing_labels,
        "native_geometry_count": native_geometry_count,
        "patched_atomic_count": patched_atomic_count,
        "replaced_existing": replaced_existing,
    }


def inject_glow_materials_into_dff(filepath, material_names, glow_color, apply_day=False, disable_normals=True, create_backup=True):
    return inject_glow_specs_into_dff(
        filepath,
        [
            {
                "label": "Manual Glow",
                "material_names": _parse_material_name_list(material_names),
                "glow_color": glow_color,
                "apply_day": apply_day,
                "disable_normals": disable_normals,
            }
        ],
        create_backup=create_backup,
    )


def _linked_light_object_poll(_self, obj):
    return obj is not None and getattr(obj, "type", "") == "MESH"


class Defacto2DFXVariantLevel(PropertyGroup):
    name: StringProperty(name="Name", default="Variant Level")
    level_index: IntProperty(name="Level", default=1, min=1, max=MAX_VARIANT_LEVELS)
    enabled: BoolProperty(name="Enabled", default=True)
    paintjob_index: IntProperty(
        name="Paintjob",
        description="-1 is the default TXD paintjob; 0..5 are GTA SA remap paintjobs",
        default=-1,
        min=-1,
        max=5,
    )
    primary_extra: IntProperty(
        name="Primary Extra",
        description="Vehicle extra id forced for this paintjob level; 0 disables the slot",
        default=1,
        min=0,
        max=6,
    )
    secondary_extra: IntProperty(
        name="Secondary Extra",
        description="Optional second vehicle extra id forced for this paintjob level; 0 disables the slot",
        default=0,
        min=0,
        max=6,
    )
    extra_mask: BoolVectorProperty(
        name="Extras",
        description="Vehicle extra objects forced visible for this paintjob level",
        size=6,
        default=(False, False, False, False, False, False),
    )


class Defacto2DFXVariantSettings(PropertyGroup):
    enabled: BoolProperty(
        name="Enable Paintjob Variants",
        description="Enable paintjob-driven extra and AELS-light variation data for export",
        default=False,
        update=_aels_preview_settings_update,
    )
    levels: CollectionProperty(type=Defacto2DFXVariantLevel)
    active_level_index: IntProperty(name="Active Level", default=0, min=0, update=_aels_preview_settings_update)
    preview_enabled: BoolProperty(
        name="Preview Lights",
        description="Draw animated AELS light markers in the Blender viewport",
        default=False,
        update=_aels_preview_settings_update,
    )
    preview_siren_active: BoolProperty(
        name="Siren",
        description="Preview lights as if the siren activation condition is currently active",
        default=True,
        update=_aels_preview_settings_update,
    )
    preview_follow_active_variant: BoolProperty(
        name="Follow Variant Tab",
        description="Preview the currently selected paintjob variant level; level 0 draws every tagged light",
        default=True,
        update=_aels_preview_settings_update,
    )
    preview_level: IntProperty(
        name="Preview Level",
        description="0 previews all lights; 1..6 previews always-active lights plus this variant level",
        default=VARIANT_LEVEL_NONE,
        min=VARIANT_LEVEL_NONE,
        max=MAX_VARIANT_LEVELS,
        update=_aels_preview_settings_update,
    )
    preview_show_inactive: BoolProperty(
        name="Dim Off",
        description="Keep lights visible at low opacity while their blink state is off",
        default=False,
        update=_aels_preview_settings_update,
    )
    preview_point_size: IntProperty(
        name="Marker Size",
        description="Base viewport marker size for previewed AELS lights",
        default=14,
        min=2,
        max=64,
        update=_aels_preview_settings_update,
    )
    preview_max_lights: IntProperty(
        name="Limit",
        description="Maximum previewed lights per viewport frame",
        default=AELS_PREVIEW_MAX_LIGHTS_DEFAULT,
        min=1,
        max=512,
        update=_aels_preview_settings_update,
    )


class Defacto2DFXEffectProperties(PropertyGroup):
    effect_kind: EnumProperty(
        name="Effect Type",
        description="Assigned GTA effect type for this object",
        items=EFFECT_KIND_ITEMS,
        default=EFFECT_NONE,
    )
    light_draw_distance: FloatProperty(name="Draw Distance", default=200.0, min=0.0)
    light_outer_range: FloatProperty(name="Outer Range", default=6.0, min=0.0)
    light_size: FloatProperty(name="Size", default=5.0, min=0.0)
    light_inner_range: FloatProperty(name="Inner Range", default=1.0, min=0.0)
    light_color_alpha: IntProperty(name="Extra Color", default=200, min=0, max=255)
    light_type: EnumProperty(
        name="Light Type",
        description="Standard GTA light type",
        items=_light_type_items,
    )
    light_corona: EnumProperty(name="Corona", items=_corona_items)
    light_shadow: EnumProperty(name="Shadow", items=_shadow_items)
    light_directional: BoolProperty(
        name="Directional",
        description="Make the corona visible only from the chosen side",
        default=False,
    )
    light_facing: EnumProperty(
        name="Facing",
        description="Side from which the corona should be visible; uses the light object's rotation",
        items=LIGHT_FACE_ITEMS,
        default=LIGHT_FACE_FRONT,
    )
    custom_blink_interval_ms: IntProperty(
        name="Blink Interval (ms)",
        description="Milliseconds per state for the custom blink type",
        default=160,
        min=1,
        max=60000,
    )
    custom_blink_start_on: BoolProperty(
        name="Start Lit",
        description="If enabled, the first pattern duration starts with the light on; otherwise it starts dark",
        default=True,
    )
    aels_use_runtime: BoolProperty(
        name="Use AELS Runtime",
        description="Mark this light as part of the advanced emergency-light system",
        default=True,
    )
    aels_vehicle_class: EnumProperty(
        name="Vehicle Class",
        description="Emergency vehicle class that this runtime light belongs to",
        items=AELS_VEHICLE_CLASS_ITEMS,
        default="ANY_EMERGENCY",
    )
    aels_requires_siren: BoolProperty(
        name="Requires Siren",
        description="Runtime light only works while the siren is active",
        default=True,
    )
    aels_blink_mode: EnumProperty(
        name="Blink Mode",
        description="Choose between a simple on/off cycle and a manual multi-step blink pattern",
        items=AELS_BLINK_MODE_ITEMS,
        default=AELS_BLINK_MODE_SIMPLE,
    )
    aels_flash_on_ms: IntProperty(
        name="Flash On (ms)",
        description="How long the light stays on during one blink cycle",
        default=160,
        min=0,
        max=60000,
    )
    aels_flash_off_ms: IntProperty(
        name="Flash Off (ms)",
        description="How long the light stays off during one blink cycle",
        default=160,
        min=0,
        max=60000,
    )
    aels_phase_offset_ms: IntProperty(
        name="Phase Offset (ms)",
        description="Offset the blink cycle to alternate left/right groups",
        default=0,
        min=-60000,
        max=60000,
    )
    aels_custom_pattern: StringProperty(
        name="Pattern",
        description="Comma-separated duration list in milliseconds, for example 100, 200, 200, 100",
        default=DEFAULT_AELS_PATTERN,
    )
    aels_export_corona: BoolProperty(
        name="Export Legacy 2DFX Effect",
        description="Also export the standard static 2DFX corona and shadow for compatibility; keep this off for animated AELS lights",
        default=False,
    )
    linked_light_object: PointerProperty(
        name="Light Object",
        description="Mesh object that should glow with this light while its blink cycle is active",
        type=bpy.types.Object,
        poll=_linked_light_object_poll,
    )
    variant_level: IntProperty(
        name="Variant Level",
        description="Paintjob variant level that owns this light; 0 means always active",
        default=VARIANT_LEVEL_NONE,
        min=VARIANT_LEVEL_NONE,
        max=MAX_VARIANT_LEVELS,
    )
    variant_extra_level: IntProperty(
        name="Extra Variant Level",
        description="Paintjob variant level that owns this extra object; 0 means unbound",
        default=VARIANT_LEVEL_NONE,
        min=VARIANT_LEVEL_NONE,
        max=MAX_VARIANT_LEVELS,
    )
    glow_enabled: BoolProperty(
        name="Glow Object",
        description="Mark this mesh object as an AELS glow-material source",
        default=False,
    )
    glow_material_names: StringProperty(
        name="Glow Materials",
        description="Detected material and texture names from this glow object",
    )
    glow_color: FloatVectorProperty(
        name="Glow Color",
        description="Night vertex color applied to this glow object",
        subtype="COLOR",
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0),
    )
    glow_apply_day: BoolProperty(
        name="Apply In Day",
        description="Also write the glow color into the daytime prelight colors",
        default=False,
    )
    glow_disable_normals: BoolProperty(
        name="Map-Style Lighting",
        description="Disable geometry normals while writing map-style glow prelight data",
        default=True,
    )


class DEFACTO2DFX_OT_reload_presets(Operator):
    bl_idname = "defacto_2dfx.reload_presets"
    bl_label = "Reload Presets"
    bl_description = "Reload saparticle.ini data for 2DFX textures and light presets"

    def execute(self, _context):
        ini_path = load_presets()
        if ini_path is None:
            self.report({"WARNING"}, "saparticle.ini not found, fallback presets loaded")
        else:
            self.report({"INFO"}, f"Loaded presets from {ini_path}")
        return {"FINISHED"}


class DEFACTO2DFX_OT_add_light_data(Operator):
    bl_idname = "defacto_2dfx.add_light_data"
    bl_label = "Add Emergency Light"
    bl_description = "Assign 2DFX emergency-light data to selected Blender light objects"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        updated = 0
        for obj in context.selected_objects:
            if obj.type != "LIGHT":
                continue
            _init_light_defaults(obj.defacto_2dfx)
            updated += 1

        if updated == 0:
            self.report({"WARNING"}, "Select at least one Blender light")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Assigned emergency-light data to {updated} object(s)")
        return {"FINISHED"}


class DEFACTO2DFX_OT_remove_data(Operator):
    bl_idname = "defacto_2dfx.remove_data"
    bl_label = "Remove Light Data"
    bl_description = "Remove 2DFX emergency-light tagging from selected objects"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        updated = 0
        for obj in context.selected_objects:
            if obj.defacto_2dfx.effect_kind == EFFECT_NONE:
                continue
            obj.defacto_2dfx.effect_kind = EFFECT_NONE
            updated += 1

        if updated == 0:
            self.report({"WARNING"}, "No tagged objects in selection")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Removed emergency-light data from {updated} object(s)")
        return {"FINISHED"}


def _active_variant_level(settings):
    index = _active_variant_level_index(settings)
    if index < 0:
        return None
    return settings.levels[index]


def _active_variant_level_index(settings):
    if len(settings.levels) == 0:
        return -1
    return max(0, min(int(settings.active_level_index), len(settings.levels) - 1))


def _normalize_extra_object_name(name):
    return re.sub(r"[^a-z0-9]", "", str(name).lower())


def _find_scene_extra_object(scene, extra_id):
    wanted = {f"extra{extra_id}", f"extr{extra_id}", f"misc{extra_id}"}
    for obj in scene.objects:
        normalized = _normalize_extra_object_name(obj.name)
        if normalized in wanted or normalized.startswith(f"extra{extra_id}"):
            return obj
    return None


def _assigned_variant_extra_objects(scene, level_id):
    return [
        obj
        for obj in scene.objects
        if obj.type not in {"LIGHT", "CAMERA"}
        and getattr(obj, "defacto_2dfx", None) is not None
        and obj.defacto_2dfx.variant_extra_level == level_id
    ]


class DEFACTO2DFX_OT_add_variant_level(Operator):
    bl_idname = "defacto_2dfx.add_variant_level"
    bl_label = "Add Variant Level"
    bl_description = "Add a paintjob variant level"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.defacto_2dfx_variants
        if len(settings.levels) >= MAX_VARIANT_LEVELS:
            self.report({"WARNING"}, f"Paintjob variants support up to {MAX_VARIANT_LEVELS} levels")
            return {"CANCELLED"}

        settings.enabled = True
        level_number = len(settings.levels) + 1
        level = settings.levels.add()
        level.level_index = level_number
        level.name = f"Level {level_number}"
        level.paintjob_index = -1 if level_number == 1 else level_number - 2
        level.primary_extra = 0
        level.secondary_extra = 0
        for extra_index in range(6):
            level.extra_mask[extra_index] = False
        settings.active_level_index = len(settings.levels) - 1
        self.report({"INFO"}, f"Added paintjob variant level {level_number}")
        return {"FINISHED"}


class DEFACTO2DFX_OT_remove_variant_level(Operator):
    bl_idname = "defacto_2dfx.remove_variant_level"
    bl_label = "Remove Variant Level"
    bl_description = "Remove the active paintjob variant level"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.defacto_2dfx_variants
        if len(settings.levels) == 0:
            self.report({"WARNING"}, "No variant levels to remove")
            return {"CANCELLED"}

        active_index = _active_variant_level_index(settings)
        level = settings.levels[active_index] if active_index >= 0 else None
        removed_level = level.level_index if level is not None else 0
        settings.levels.remove(active_index)
        settings.active_level_index = max(0, min(active_index, len(settings.levels) - 1))
        for obj in context.scene.objects:
            props = getattr(obj, "defacto_2dfx", None)
            if props is None:
                continue
            if props.variant_level == removed_level:
                props.variant_level = VARIANT_LEVEL_NONE
            if props.variant_extra_level == removed_level:
                props.variant_extra_level = VARIANT_LEVEL_NONE
        self.report({"INFO"}, f"Removed variant level {removed_level}")
        return {"FINISHED"}


class DEFACTO2DFX_OT_set_active_variant_level(Operator):
    bl_idname = "defacto_2dfx.set_active_variant_level"
    bl_label = "Set Active Variant Level"
    bl_description = "Make this paintjob variant level active in the panel"
    bl_options = {"REGISTER", "UNDO"}

    index: IntProperty(default=0, min=0)

    def execute(self, context):
        settings = context.scene.defacto_2dfx_variants
        if len(settings.levels) == 0:
            return {"CANCELLED"}
        settings.active_level_index = max(0, min(self.index, len(settings.levels) - 1))
        return {"FINISHED"}


class DEFACTO2DFX_OT_assign_lights_to_variant_level(Operator):
    bl_idname = "defacto_2dfx.assign_lights_to_variant_level"
    bl_label = "Assign Selected Lights"
    bl_description = "Bind selected AELS light objects to the active paintjob variant level"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.defacto_2dfx_variants
        level = _active_variant_level(settings)
        if level is None:
            self.report({"WARNING"}, "Add a variant level first")
            return {"CANCELLED"}

        updated = 0
        for obj in context.selected_objects:
            if obj.type != "LIGHT":
                continue
            props = obj.defacto_2dfx
            if props.effect_kind != EFFECT_LIGHT:
                _init_light_defaults(props)
            props.variant_level = level.level_index
            updated += 1

        if updated == 0:
            self.report({"WARNING"}, "Select at least one Blender light")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Assigned {updated} light(s) to variant level {level.level_index}")
        return {"FINISHED"}


class DEFACTO2DFX_OT_clear_lights_variant_level(Operator):
    bl_idname = "defacto_2dfx.clear_lights_variant_level"
    bl_label = "Clear Selected Binding"
    bl_description = "Make selected AELS lights active for every paintjob variant"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        updated = 0
        for obj in context.selected_objects:
            props = getattr(obj, "defacto_2dfx", None)
            if obj.type == "LIGHT" and props is not None and props.variant_level != VARIANT_LEVEL_NONE:
                props.variant_level = VARIANT_LEVEL_NONE
                updated += 1
        if updated == 0:
            self.report({"WARNING"}, "No selected variant-bound lights")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Cleared variant binding from {updated} light(s)")
        return {"FINISHED"}


class DEFACTO2DFX_OT_assign_extras_to_variant_level(Operator):
    bl_idname = "defacto_2dfx.assign_extras_to_variant_level"
    bl_label = "Assign Selected Objects"
    bl_description = "Bind selected named objects to the active paintjob variant level; their child atomics follow the same level in game"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.defacto_2dfx_variants
        level = _active_variant_level(settings)
        if level is None:
            self.report({"WARNING"}, "Add a variant level first")
            return {"CANCELLED"}

        updated = 0
        for obj in context.selected_objects:
            if obj.type in {"LIGHT", "CAMERA"}:
                continue
            if not _variant_object_export_name(obj.name):
                continue

            obj.defacto_2dfx.variant_extra_level = level.level_index
            updated += 1

        if updated == 0:
            self.report({"WARNING"}, "Select at least one named mesh or parent object")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Assigned {updated} variant object(s) to level {level.level_index}")
        return {"FINISHED"}


class DEFACTO2DFX_OT_clear_extras_variant_level(Operator):
    bl_idname = "defacto_2dfx.clear_extras_variant_level"
    bl_label = "Clear Selected Objects"
    bl_description = "Remove selected named-object bindings from paintjob variant levels"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        updated = 0
        for obj in context.selected_objects:
            props = getattr(obj, "defacto_2dfx", None)
            if obj.type not in {"LIGHT", "CAMERA"} and props is not None and props.variant_extra_level != VARIANT_LEVEL_NONE:
                props.variant_extra_level = VARIANT_LEVEL_NONE
                updated += 1

        if updated == 0:
            self.report({"WARNING"}, "No selected variant-bound objects")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Cleared variant binding from {updated} object(s)")
        return {"FINISHED"}


class DEFACTO2DFX_OT_export_sae(Operator, ExportHelper):
    bl_idname = "export_scene.defacto_2dfx"
    bl_label = "Export 2DFX Light Data (.sae)"
    bl_description = "Export GTA San Andreas 2DFX light data to a .sae binary file"

    filename_ext = ".sae"
    filter_glob: StringProperty(default="*.sae", options={"HIDDEN"})
    use_selection_only: BoolProperty(
        name="Selection Only",
        description="Export only selected objects with assigned SA effect data",
        default=False,
    )

    def execute(self, context):
        objects = _collect_export_objects(context, self.use_selection_only)
        if not objects:
            self.report({"WARNING"}, "No emergency-light objects found for export")
            return {"CANCELLED"}

        try:
            export_sae(self.filepath, objects)
        except OSError as exc:
            self.report({"ERROR"}, f"Failed to export .sae file: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Exported {len(objects)} light object(s)")
        return {"FINISHED"}


class DEFACTO2DFX_OT_export_aels_ini(Operator, ExportHelper):
    bl_idname = "export_scene.defacto_2dfx_aels_ini"
    bl_label = "Export AELS Runtime (.ini, Optional)"
    bl_description = "Export advanced emergency-light settings to an optional INI compatibility file"

    filename_ext = ".ini"
    filter_glob: StringProperty(default="*.ini", options={"HIDDEN"})
    use_selection_only: BoolProperty(
        name="Selection Only",
        description="Export only selected tagged objects into the AELS INI file",
        default=False,
    )

    def execute(self, context):
        objects = _collect_export_objects(context, self.use_selection_only)
        if not objects:
            self.report({"WARNING"}, "No emergency-light objects found for AELS INI export")
            return {"CANCELLED"}

        try:
            export_aels_ini(self.filepath, objects)
        except (OSError, ValueError) as exc:
            self.report({"ERROR"}, f"Failed to export AELS INI: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Exported AELS INI for {len(objects)} light object(s)")
        return {"FINISHED"}


class DEFACTO2DFX_OT_apply_to_dff(Operator, ImportHelper):
    bl_idname = "defacto_2dfx.apply_to_dff"
    bl_label = "Apply To DFF"
    bl_description = "Inject the current 2DFX data into a DFF model and embed AELS runtime data for custom blink lights"

    filename_ext = ".dff"
    filter_glob: StringProperty(default="*.dff", options={"HIDDEN"})
    use_selection_only: BoolProperty(
        name="Selection Only",
        description="Use only selected tagged objects when building the DFF data; leave this off to export the whole emergency-light setup",
        default=False,
    )
    create_backup: BoolProperty(
        name="Create Backup",
        description="Create a backup copy before overwriting the selected DFF",
        default=True,
    )
    def execute(self, context):
        objects = _collect_export_objects(context, self.use_selection_only)
        if not objects:
            self.report({"WARNING"}, "No emergency-light objects found to apply")
            return {"CANCELLED"}

        try:
            aels_bytes = build_aels_metadata_bytes(objects)
            result = inject_sae_into_dff(
                self.filepath,
                build_sae_bytes(objects),
                aels_bytes=aels_bytes,
                create_backup=self.create_backup,
                strip_aels=aels_bytes is None,
            )
        except (OSError, ValueError) as exc:
            self.report({"ERROR"}, f"Failed to update DFF: {exc}")
            return {"CANCELLED"}

        action = "Replaced" if result["replaced_existing"] else "Added"
        backup_note = f" Backup: {Path(result['backup_path']).name}" if result["backup_path"] else ""
        runtime_note = " Embedded AELS runtime data." if result["aels_embedded"] else " Removed old AELS runtime data."
        static_glow_removed = (
            result.get("aels_static_glow_extra_removed", 0) +
            result.get("aels_static_glow_prelit_removed", 0) +
            result.get("aels_static_glow_pipeline_removed", 0)
        )
        static_glow_note = f" Cleaned {static_glow_removed} old static glow marker(s)." if static_glow_removed else ""
        self.report(
            {"INFO"},
            f"{action} 2DFX on geometry {result['geometry_index']} in {Path(self.filepath).name}.{backup_note}{runtime_note}{static_glow_note}",
        )
        return {"FINISHED"}


class DEFACTO2DFX_PT_setup(Panel):
    bl_label = "2DFX AELS"
    bl_idname = "DEFACTO2DFX_PT_setup"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "2DFX AELS"

    def draw(self, context):
        layout = self.layout
        ini_path = PRESET_CACHE["ini_path"]
        if ini_path:
            layout.label(text=f"Presets: {Path(ini_path).name}")
        else:
            layout.label(text="Presets: fallback values")

        col = layout.column(align=True)
        col.operator("defacto_2dfx.add_light_data")

        layout.separator()
        row = layout.row(align=True)
        row.operator("defacto_2dfx.remove_data")
        row.operator("defacto_2dfx.reload_presets")

        layout.label(text="Light-only workflow for GTA SA 2DFX.")
        layout.label(text="Use one Blender Light per emergency-light point.")


class DEFACTO2DFX_PT_active_object(Panel):
    bl_label = "Active Object"
    bl_idname = "DEFACTO2DFX_PT_active_object"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "2DFX AELS"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        if obj is None:
            layout.label(text="No active object.")
            return

        props = obj.defacto_2dfx
        layout.label(text=f"Object: {obj.name}")
        layout.label(text=f"Type: {obj.type}")

        if props.effect_kind != EFFECT_LIGHT:
            layout.label(text="No emergency-light data assigned.")
            return

        layout.label(text="Effect: Light")
        if obj.type != "LIGHT":
            layout.label(text="Warning: emergency-light data expects a Light object.")
            return

        layout.prop(obj.data, "color", text="Color")
        layout.prop(props, "light_draw_distance")
        layout.prop(props, "light_outer_range")
        layout.prop(props, "light_size")
        layout.prop(props, "light_inner_range")
        layout.prop(props, "light_color_alpha")
        layout.prop(props, "light_corona")
        layout.prop(props, "light_shadow")
        layout.prop(props, "linked_light_object")
        layout.separator()
        layout.prop(props, "light_directional")
        if props.light_directional:
            layout.prop(props, "light_facing")
            layout.label(text="Corona and shadow use the light's visible rotation.")
        layout.separator()
        layout.label(text="All lights use the AELS custom blink runtime.")
        layout.prop(props, "aels_custom_pattern")
        layout.prop(props, "custom_blink_start_on")
        if getattr(props, "linked_light_object", None) is not None:
            layout.label(text="The linked mesh object glows only while this light is ON.")
        layout.label(text="Lights activate from siren or L.")


class DEFACTO2DFX_PT_light_preview(Panel):
    bl_label = "Light Preview"
    bl_idname = "DEFACTO2DFX_PT_light_preview"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "2DFX AELS"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.defacto_2dfx_variants

        if gpu is None or batch_for_shader is None:
            layout.label(text="Viewport GPU preview is unavailable.")
            return

        layout.prop(settings, "preview_enabled", toggle=True)

        column = layout.column(align=True)
        column.enabled = bool(settings.preview_enabled)
        row = column.row(align=True)
        row.prop(settings, "preview_siren_active", toggle=True)
        row.prop(settings, "preview_show_inactive", toggle=True)

        column.prop(settings, "preview_follow_active_variant")
        level_row = column.row(align=True)
        level_row.enabled = not bool(settings.preview_follow_active_variant)
        level_row.prop(settings, "preview_level")

        row = column.row(align=True)
        row.prop(settings, "preview_point_size")
        row.prop(settings, "preview_max_lights")


class DEFACTO2DFX_PT_export(Panel):
    bl_label = "Export"
    bl_idname = "DEFACTO2DFX_PT_export"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "2DFX AELS"

    def draw(self, _context):
        layout = self.layout
        layout.operator("defacto_2dfx.apply_to_dff")
        layout.operator("export_scene.defacto_2dfx")
        layout.label(text="The full tagged light setup is exported by default.")
        layout.label(text="Apply To DFF embeds siren-bound AELS data for all light types.")
        layout.label(text="A .bak copy can be created in the file browser.")


class DEFACTO2DFX_PT_paintjob_variants(Panel):
    bl_label = "Paintjob Variants"
    bl_idname = "DEFACTO2DFX_PT_paintjob_variants"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "2DFX Variants"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.defacto_2dfx_variants
        layout.prop(settings, "enabled")

        row = layout.row(align=True)
        row.operator("defacto_2dfx.add_variant_level", text="Add Level", icon="ADD")
        row.operator("defacto_2dfx.remove_variant_level", text="", icon="REMOVE")

        if not settings.enabled:
            layout.label(text="Variant data is not exported.")
            return

        if len(settings.levels) == 0:
            layout.label(text="Add a level to configure paintjob variants.")
            return

        layout.separator()
        active_index = _active_variant_level_index(settings)
        tabs = layout.row(align=True)
        for index, level in enumerate(settings.levels):
            op = tabs.operator(
                "defacto_2dfx.set_active_variant_level",
                text=str(level.level_index),
                depress=index == active_index,
            )
            op.index = index

        level = _active_variant_level(settings)
        if level is None:
            return

        box = layout.box()
        box.prop(level, "enabled")
        box.prop(level, "name")
        box.prop(level, "paintjob_index")
        assigned_extras = _assigned_variant_extra_objects(context.scene, level.level_index)
        box.label(text=f"Variant objects: {len(assigned_extras)}")
        for obj in assigned_extras:
            extra_id = _extra_id_from_object_name(obj.name)
            prefix = f"Extra {extra_id}: " if 1 <= extra_id <= 6 else ""
            box.label(text=f"{prefix}{obj.name}")
        row = box.row(align=True)
        row.operator("defacto_2dfx.assign_extras_to_variant_level")
        row.operator("defacto_2dfx.clear_extras_variant_level")

        assigned_count = sum(
            1
            for obj in context.scene.objects
            if obj.type == "LIGHT"
            and getattr(obj, "defacto_2dfx", None) is not None
            and obj.defacto_2dfx.variant_level == level.level_index
        )
        box.label(text=f"Bound lights: {assigned_count}")
        row = box.row(align=True)
        row.operator("defacto_2dfx.assign_lights_to_variant_level")
        row.operator("defacto_2dfx.clear_lights_variant_level")

        obj = context.object
        if obj is not None and obj.type == "LIGHT" and getattr(obj, "defacto_2dfx", None) is not None:
            layout.separator()
            layout.label(text=f"Active light: {obj.name}")
            layout.prop(obj.defacto_2dfx, "variant_level")


class DEFACTO2DFX_PT_light_material(Panel):
    bl_label = "Light Material"
    bl_idname = "DEFACTO2DFX_PT_light_material"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "2DFX AELS"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        material = bpy.data.materials.get(AELS_LIGHT_MATERIAL_NAME)
        image = bpy.data.images.get(AELS_LIGHT_TEXTURE_NAME)

        layout.label(text=f"Material: {material.name if material else AELS_LIGHT_MATERIAL_NAME}")
        layout.label(text=f"Off texture: {image.name if image else AELS_LIGHT_TEXTURE_NAME}")
        layout.label(text=f"On texture in TXD: {AELS_LIGHT_ON_TEXTURE_NAME}")

        if obj is None or obj.type != "MESH":
            return

        has_aels_material = any(
            slot.material is not None and slot.material.name == AELS_LIGHT_MATERIAL_NAME
            for slot in obj.material_slots
        )
        layout.label(text=f"Active mesh uses material: {'yes' if has_aels_material else 'no'}")


def menu_func_export(self, _context):
    self.layout.operator(DEFACTO2DFX_OT_export_sae.bl_idname, text="2DFX AELS Light Data (.sae)")


CLASSES = (
    Defacto2DFXVariantLevel,
    Defacto2DFXVariantSettings,
    Defacto2DFXEffectProperties,
    DEFACTO2DFX_OT_reload_presets,
    DEFACTO2DFX_OT_add_light_data,
    DEFACTO2DFX_OT_remove_data,
    DEFACTO2DFX_OT_add_variant_level,
    DEFACTO2DFX_OT_remove_variant_level,
    DEFACTO2DFX_OT_set_active_variant_level,
    DEFACTO2DFX_OT_assign_lights_to_variant_level,
    DEFACTO2DFX_OT_clear_lights_variant_level,
    DEFACTO2DFX_OT_assign_extras_to_variant_level,
    DEFACTO2DFX_OT_clear_extras_variant_level,
    DEFACTO2DFX_OT_export_sae,
    DEFACTO2DFX_OT_apply_to_dff,
    DEFACTO2DFX_PT_setup,
    DEFACTO2DFX_PT_active_object,
    DEFACTO2DFX_PT_light_preview,
    DEFACTO2DFX_PT_export,
    DEFACTO2DFX_PT_paintjob_variants,
    DEFACTO2DFX_PT_light_material,
)


def register():
    load_presets()
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.defacto_2dfx = PointerProperty(type=Defacto2DFXEffectProperties)
    bpy.types.Scene.defacto_2dfx_variants = PointerProperty(type=Defacto2DFXVariantSettings)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    _aels_preview_ensure()


def unregister():
    global _AELS_PREVIEW_TIMER_ACTIVE
    _AELS_PREVIEW_TIMER_ACTIVE = False
    _aels_preview_remove_handler()
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    del bpy.types.Scene.defacto_2dfx_variants
    del bpy.types.Object.defacto_2dfx
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
