script_name("2DFX_AELS")
script_author("de-facto")
script_dependencies("SAMP")

require "lib.moonloader"

local MOD_NAME = "2DFX AELS"
local MOD_VERSION = "0.6.1"
local MOD_AUTHOR = "de-facto"

local commandPath = nil
local resultPath = nil
local settingsPath = nil
local uiStatePath = nil
local lastResultSerial = 0

local encodingOk, encoding = pcall(require, "encoding")
local u8 = nil
if encodingOk and encoding ~= nil then
    encoding.default = "CP1251"
    u8 = encoding.UTF8
end

local DIALOG_MAIN = 28200
local DIALOG_HELP = 28201
local DIALOG_MODELS = 28202
local DIALOG_LEVELS = 28203
local DIALOG_PERCENT = 28204
local MODELS_PER_PAGE = 35
local AELS_DIALOGS = { DIALOG_MAIN, DIALOG_HELP, DIALOG_MODELS, DIALOG_LEVELS, DIALOG_PERCENT }

local ui = {
    dialog = 0,
    items = {},
    modelPage = 1,
    modelIndex = 1,
    levelId = 0
}

local state = {
    randomEnabled = true,
    models = {}
}

local settings = {
    randomEnabled = true,
    weights = {}
}

local function cp(text)
    if text == nil then
        return ""
    end
    if u8 ~= nil then
        return u8:decode(text)
    end
    return text
end

local function printChat(message, color)
    if sampAddChatMessage ~= nil and message ~= nil and message ~= "" then
        sampAddChatMessage(cp(message), color or 0x66CCFF)
    end
end

local function trim(value)
    if value == nil then
        return ""
    end
    return (value:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function readKeyValueFile(path)
    local values = {}
    if path == nil then
        return values
    end

    local file = io.open(path, "r")
    if file == nil then
        return values
    end

    for line in file:lines() do
        local key, value = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
        if key ~= nil then
            values[key] = value
        end
    end
    file:close()
    return values
end

local function readIni(path)
    local sections = {}
    local current = ""
    if path == nil then
        return sections
    end

    local file = io.open(path, "r")
    if file == nil then
        return sections
    end

    for rawLine in file:lines() do
        local line = rawLine:gsub("[;#].*$", "")
        local section = line:match("^%s*%[(.-)%]%s*$")
        if section ~= nil then
            current = trim(section)
            if sections[current] == nil then
                sections[current] = {}
            end
        else
            local key, value = line:match("^%s*([^=]+)%s*=%s*(.-)%s*$")
            if key ~= nil then
                if sections[current] == nil then
                    sections[current] = {}
                end
                sections[current][trim(key)] = trim(value)
            end
        end
    end
    file:close()
    return sections
end

local function readSerial()
    local values = readKeyValueFile(commandPath)
    return tonumber(values.serial) or 0
end

local function writeCommand(lines)
    if commandPath == nil then
        return
    end

    local serial = readSerial() + 1
    local file = io.open(commandPath, "w")
    if file == nil then
        return
    end

    file:write("[command]\n")
    for _, line in ipairs(lines) do
        file:write(line .. "\n")
    end
    file:write("serial=" .. tostring(serial) .. "\n")
    file:close()
end

local function normalizeUserPaintjob(value)
    if value == -1 or value == -999 then
        return value
    end
    if value == 0 then
        return -1
    end
    if value >= 1 and value <= 6 then
        return value - 1
    end
    return nil
end

local function paintjobCommandLabel(userPaintjob, paintjob)
    if paintjob == -999 then
        return "reset"
    end
    if paintjob == -1 then
        return "level 1 / no paintjob"
    end
    if userPaintjob ~= nil and userPaintjob >= 1 and userPaintjob <= 6 then
        return string.format("level %d / paintjob %d", userPaintjob + 1, paintjob)
    end
    return string.format("GTA remap %d", paintjob)
end

local function writePaintjobCommand(paintjob, userPaintjob)
    writeCommand({ "paintjob=" .. tostring(paintjob) })
    printChat(string.format("2DFX AELS: paintjob request: %s.", paintjobCommandLabel(userPaintjob, paintjob)), 0x66CCFF)
end

local function pollPaintjobResult()
    local values = readKeyValueFile(resultPath)
    local serial = tonumber(values.serial) or 0
    if serial == 0 or serial == lastResultSerial then
        return
    end

    lastResultSerial = serial
    local status = tonumber(values.status) or 0
    local color = status == 1 and 0x66CCFF or 0xFF6666
    printChat(values.message, color)
end

local function printUsage()
    printChat("2DFX AELS: используйте /aelspj 0..6, /aelspj_default или /aelspj_reset.", 0xFFCC66)
end

local function handlePaintjobCommand(userPaintjob)
    if userPaintjob == nil then
        printUsage()
        return
    end

    local paintjob = normalizeUserPaintjob(userPaintjob)
    if paintjob == nil then
        printUsage()
        return
    end

    writePaintjobCommand(paintjob, userPaintjob)
end

local function registerFixedCommand(name, userPaintjob)
    sampRegisterChatCommand(name, function()
        handlePaintjobCommand(userPaintjob)
    end)
end

local function loadSettings()
    settings = {
        randomEnabled = true,
        weights = {}
    }

    local ini = readIni(settingsPath)
    for sectionName, values in pairs(ini) do
        local lowerSection = sectionName:lower()
        if lowerSection == "randomaelspj" then
            local enabled = tonumber(values.Enabled or values.enabled)
            if enabled ~= nil then
                settings.randomEnabled = enabled ~= 0
            end
        else
            local modelName = lowerSection:match("^randomaelspj%.model%.(.+)$")
            if modelName ~= nil then
                settings.weights[modelName] = settings.weights[modelName] or {}
                for key, value in pairs(values) do
                    local level = key:lower():match("^level(%d+)$")
                    if level ~= nil then
                        settings.weights[modelName][tonumber(level)] = math.max(0, math.min(100, tonumber(value) or 0))
                    end
                end
            end
        end
    end
end

local function loadUiState()
    local ini = readIni(uiStatePath)
    local meta = ini.meta or ini.Meta or {}
    local modelCount = tonumber(meta.model_count) or 0

    state = {
        randomEnabled = (tonumber(meta.random_enabled) or 1) ~= 0,
        models = {}
    }

    for index = 1, modelCount do
        local section = ini["model." .. tostring(index)]
        if section ~= nil and section.name ~= nil then
            local model = {
                name = section.name,
                modelId = tonumber(section.model_id) or -1,
                levels = {}
            }
            local levelCount = tonumber(section.level_count) or 0
            for levelIndex = 1, levelCount do
                local level = tonumber(section["level" .. levelIndex .. "_id"]) or 0
                if level ~= 0 then
                    table.insert(model.levels, {
                        id = level,
                        paintjob = tonumber(section["level" .. levelIndex .. "_paintjob"]) or -1,
                        percent = tonumber(section["level" .. levelIndex .. "_percent"]) or 0
                    })
                end
            end
            table.insert(state.models, model)
        end
    end
end

local function defaultPercent(index, count)
    if count <= 0 then
        return 0
    end
    local base = math.floor(100 / count)
    local remainder = 100 % count
    if index <= remainder then
        return base + 1
    end
    return base
end

local function modelKey(model)
    return (model.name or ""):lower()
end

local function currentWeights(model)
    local result = {}
    local configured = settings.weights[modelKey(model)]
    local total = 0

    for index, level in ipairs(model.levels) do
        local value = level.percent or defaultPercent(index, #model.levels)
        if configured ~= nil and configured[level.id] ~= nil then
            value = configured[level.id]
        end
        value = math.max(0, math.min(100, value))
        result[index] = value
        total = total + value
    end

    if total <= 0 then
        for index, _ in ipairs(model.levels) do
            result[index] = defaultPercent(index, #model.levels)
        end
    end
    return result
end

local function applyWeightsToState(model, weights)
    for index, level in ipairs(model.levels) do
        level.percent = weights[index] or 0
    end
end

local function setModelWeights(model, weights)
    local key = modelKey(model)
    settings.weights[key] = settings.weights[key] or {}
    for index, level in ipairs(model.levels) do
        settings.weights[key][level.id] = math.max(0, math.min(100, weights[index] or 0))
    end
    applyWeightsToState(model, weights)
end

local function equalWeights(model)
    local weights = {}
    for index, _ in ipairs(model.levels) do
        weights[index] = defaultPercent(index, #model.levels)
    end
    setModelWeights(model, weights)
end

local function setLevelPercent(model, targetLevel, targetPercent)
    local weights = currentWeights(model)
    local targetIndex = nil
    for index, level in ipairs(model.levels) do
        if level.id == targetLevel then
            targetIndex = index
            break
        end
    end
    if targetIndex == nil then
        return
    end

    targetPercent = math.max(0, math.min(100, targetPercent))
    if #model.levels == 1 then
        targetPercent = 100
    end

    local remaining = 100 - targetPercent
    local otherTotal = 0
    for index, value in ipairs(weights) do
        if index ~= targetIndex then
            otherTotal = otherTotal + value
        end
    end

    local newWeights = {}
    newWeights[targetIndex] = targetPercent
    local allocated = 0
    local remainingSlots = #model.levels - 1
    for index, value in ipairs(weights) do
        if index ~= targetIndex then
            remainingSlots = remainingSlots - 1
            local newValue = 0
            if remainingSlots == 0 then
                newValue = remaining - allocated
            elseif otherTotal > 0 then
                newValue = math.floor((value * remaining) / otherTotal)
            else
                newValue = math.floor(remaining / (#model.levels - 1))
            end
            newValue = math.max(0, math.min(100, newValue))
            allocated = allocated + newValue
            newWeights[index] = newValue
        end
    end

    setModelWeights(model, newWeights)
end

local function sortedModelKeys()
    local keys = {}
    for key, _ in pairs(settings.weights) do
        table.insert(keys, key)
    end
    table.sort(keys)
    return keys
end

local function saveSettings()
    if settingsPath == nil then
        return false
    end

    local file = io.open(settingsPath, "w")
    if file == nil then
        return false
    end

    file:write("[RandomAelspj]\n")
    file:write("; 1 = assign a random AELS paintjob level per SA-MP server vehicle id.\n")
    file:write("; 0 = keep only the real GTA paintjob or manual /aelspj overrides.\n")
    file:write("; Edited by /aels MoonLoader dialog.\n")
    file:write("Enabled=" .. (settings.randomEnabled and "1" or "0") .. "\n")

    for _, key in ipairs(sortedModelKeys()) do
        file:write("\n[RandomAelspj.Model." .. key .. "]\n")
        local levels = {}
        for level, _ in pairs(settings.weights[key]) do
            table.insert(levels, level)
        end
        table.sort(levels)
        for _, level in ipairs(levels) do
            file:write("Level" .. tostring(level) .. "=" .. tostring(settings.weights[key][level]) .. "\n")
        end
    end

    file:close()
    return true
end

local function saveSettingsAndReload()
    if saveSettings() then
        writeCommand({ "reload_settings=1" })
        printChat("2DFX AELS: настройки сохранены и отправлены в ASI.", 0x66CCFF)
    else
        printChat("2DFX AELS: не удалось сохранить настройки.", 0xFF6666)
    end
end

local function percentSummary(model)
    local weights = currentWeights(model)
    local parts = {}
    local total = 0
    for index, level in ipairs(model.levels) do
        local value = weights[index] or 0
        total = total + value
        table.insert(parts, string.format("L%d %d%%", level.id, value))
    end
    return table.concat(parts, ", ") .. string.format(" | сумма %d%%", total)
end

local function showList(dialogId, title, rows, items, left, right)
    ui.dialog = dialogId
    ui.items = items or {}
    sampShowDialog(dialogId, cp(title), cp(table.concat(rows, "\n")), cp(left or "Выбрать"), cp(right or "Назад"), 2)
end

local function openHelp()
    ui.dialog = DIALOG_HELP
    ui.items = {}
    local text = table.concat({
        MOD_NAME .. " v" .. MOD_VERSION,
        "Создатель: " .. MOD_AUTHOR,
        "",
        "/aels - открыть это меню",
        "/aelspj 0..6 - вручную выбрать AELS-уровень для текущей машины",
        "/aelspj_reset - сбросить ручной выбор",
        "",
        "Проценты случайного AELSPJ настраиваются отдельно для каждой адаптированной машины.",
        "Выберите машину и уровень, затем вручную введите шанс спавна от 0 до 100."
    }, "\n")
    sampShowDialog(DIALOG_HELP, cp("2DFX AELS - помощь"), cp(text), cp("Назад"), "", 0)
end

local function openMain()
    loadSettings()
    loadUiState()

    local rows = {
        "Помощь по командам",
        "Случайный AELSPJ: " .. (settings.randomEnabled and "ВКЛ" or "ВЫКЛ"),
        "Проценты спавна по машинам",
        "Перезагрузить список из ASI"
    }
    local items = {
        { action = "help" },
        { action = "toggle_random" },
        { action = "models" },
        { action = "reload" }
    }
    showList(DIALOG_MAIN, "2DFX AELS", rows, items, "Выбрать", "Закрыть")
end

local function openModels()
    loadUiState()
    loadSettings()

    local rows = {}
    local items = {}
    if #state.models == 0 then
        rows = {
            "Список адаптированных машин пока пуст.",
            "Если модели уже загружены, подождите пару секунд и нажмите Перезагрузить."
        }
        items = {
            { action = "reload" },
            { action = "reload" }
        }
    else
        local pageCount = math.max(1, math.ceil(#state.models / MODELS_PER_PAGE))
        if ui.modelPage < 1 then ui.modelPage = 1 end
        if ui.modelPage > pageCount then ui.modelPage = pageCount end

        if ui.modelPage > 1 then
            table.insert(rows, "< Предыдущая страница")
            table.insert(items, { action = "prev_page" })
        end

        local first = (ui.modelPage - 1) * MODELS_PER_PAGE + 1
        local last = math.min(#state.models, first + MODELS_PER_PAGE - 1)
        for index = first, last do
            local model = state.models[index]
            table.insert(rows, string.format("%s | %s", model.name, percentSummary(model)))
            table.insert(items, { action = "model", modelIndex = index })
        end

        if ui.modelPage < pageCount then
            table.insert(rows, "Следующая страница >")
            table.insert(items, { action = "next_page" })
        end
    end

    showList(DIALOG_MODELS, "AELS: проценты по машинам", rows, items, "Выбрать", "Назад")
end

local function openLevels(modelIndex)
    local model = state.models[modelIndex]
    if model == nil then
        openModels()
        return
    end

    ui.modelIndex = modelIndex
    local weights = currentWeights(model)
    local rows = {}
    local items = {}

    for index, level in ipairs(model.levels) do
        table.insert(rows, string.format("Уровень %d | paintjob %d | %d%%", level.id, level.paintjob, weights[index] or 0))
        table.insert(items, { action = "level", modelIndex = modelIndex, levelId = level.id })
    end

    table.insert(rows, "Сбросить эту машину на равные шансы")
    table.insert(items, { action = "equal", modelIndex = modelIndex })

    showList(DIALOG_LEVELS, "AELS уровни: " .. model.name, rows, items, "Выбрать", "Назад")
end

local function openPercent(modelIndex, levelId)
    ui.modelIndex = modelIndex
    ui.levelId = levelId
    ui.dialog = DIALOG_PERCENT
    ui.items = {}

    local model = state.models[modelIndex]
    local currentPercent = 0
    if model ~= nil then
        local weights = currentWeights(model)
        for index, level in ipairs(model.levels) do
            if level.id == levelId then
                currentPercent = weights[index] or 0
                break
            end
        end
    end

    local text = table.concat({
        "Введите шанс спавна уровня " .. tostring(levelId) .. " вручную.",
        "Допустимый диапазон: 0..100.",
        "Текущее значение: " .. tostring(currentPercent) .. "%."
    }, "\n")
    sampShowDialog(DIALOG_PERCENT, cp("Шанс уровня " .. tostring(levelId)), cp(text), cp("Применить"), cp("Назад"), 1)
end

local function applyPercentInput(input)
    local model = state.models[ui.modelIndex]
    if model == nil then
        openModels()
        return
    end

    local text = trim(input or ""):gsub("%%", ""):gsub(",", ".")
    local percent = tonumber(text)
    if percent == nil then
        printChat("2DFX AELS: введите число от 0 до 100.", 0xFF6666)
        openPercent(ui.modelIndex, ui.levelId)
        return
    end

    percent = math.floor(percent + 0.5)
    if percent < 0 or percent > 100 then
        printChat("2DFX AELS: процент должен быть от 0 до 100.", 0xFF6666)
        openPercent(ui.modelIndex, ui.levelId)
        return
    end

    setLevelPercent(model, ui.levelId, percent)
    saveSettingsAndReload()
    openLevels(ui.modelIndex)
end

local function handleDialog(dialogId, button, list, input)
    if dialogId == DIALOG_HELP then
        openMain()
        return
    end

    if button == 0 then
        if dialogId == DIALOG_MODELS then
            openMain()
        elseif dialogId == DIALOG_LEVELS then
            openModels()
        elseif dialogId == DIALOG_PERCENT then
            openLevels(ui.modelIndex)
        end
        return
    end

    if dialogId == DIALOG_PERCENT then
        applyPercentInput(input)
        return
    end

    local item = ui.items[(list or 0) + 1]
    if item == nil then
        return
    end

    if item.action == "help" then
        openHelp()
    elseif item.action == "toggle_random" then
        settings.randomEnabled = not settings.randomEnabled
        state.randomEnabled = settings.randomEnabled
        saveSettingsAndReload()
        openMain()
    elseif item.action == "models" then
        ui.modelPage = 1
        openModels()
    elseif item.action == "reload" then
        loadUiState()
        loadSettings()
        openMain()
    elseif item.action == "prev_page" then
        ui.modelPage = ui.modelPage - 1
        openModels()
    elseif item.action == "next_page" then
        ui.modelPage = ui.modelPage + 1
        openModels()
    elseif item.action == "model" then
        openLevels(item.modelIndex)
    elseif item.action == "level" then
        openPercent(item.modelIndex, item.levelId)
    elseif item.action == "equal" then
        local model = state.models[item.modelIndex]
        if model ~= nil then
            equalWeights(model)
            saveSettingsAndReload()
        end
        openLevels(item.modelIndex)
    end
end

function main()
    if type(isSampAvailable) ~= "function" then
        print("2DFX_AELS: SA-MP MoonLoader API is unavailable; /aels and /aelspj cannot be registered.")
        return
    end

    repeat
        wait(500)
    until isSampAvailable()

    if type(sampRegisterChatCommand) ~= "function" then
        print("2DFX_AELS: sampRegisterChatCommand is unavailable; /aels and /aelspj cannot be registered.")
        return
    end

    commandPath = getWorkingDirectory() .. "\\..\\2DFX_AELS_Command.ini"
    resultPath = getWorkingDirectory() .. "\\..\\2DFX_AELS_CommandResult.ini"
    settingsPath = getWorkingDirectory() .. "\\..\\2DFX_AELS_Settings.ini"
    uiStatePath = getWorkingDirectory() .. "\\..\\2DFX_AELS_UiState.ini"
    os.remove(commandPath)
    os.remove(resultPath)

    sampRegisterChatCommand("aels", function()
        openMain()
    end)

    sampRegisterChatCommand("aelspj", function(param)
        local userPaintjob = tonumber(param)
        handlePaintjobCommand(userPaintjob)
    end)

    registerFixedCommand("aelspj0", 0)
    registerFixedCommand("aelspj1", 1)
    registerFixedCommand("aelspj2", 2)
    registerFixedCommand("aelspj3", 3)
    registerFixedCommand("aelspj4", 4)
    registerFixedCommand("aelspj5", 5)
    registerFixedCommand("aelspj6", 6)
    registerFixedCommand("aelspj_default", -1)
    registerFixedCommand("aelspj_reset", -999)

    while true do
        wait(100)
        pollPaintjobResult()

        if type(sampHasDialogRespond) == "function" then
            for _, dialogId in ipairs(AELS_DIALOGS) do
                local responded, button, list, input = sampHasDialogRespond(dialogId)
                if responded then
                    handleDialog(dialogId, button, list, input)
                end
            end
        end
    end
end
